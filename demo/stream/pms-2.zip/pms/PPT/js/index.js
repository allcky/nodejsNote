////切换页面
//angular.module('app', ['ngRoute'])
//.controller('firController', function ($scope, $route) { $scope.$route = $route;})
//.controller('secController', function ($scope, $route) { $scope.$route = $route;})
//.controller('thirController', function ($scope, $route) { $scope.$route = $route;})
//.config(['$routeProvider', function($routeProvider) {
//	$routeProvider
//		.when('/', {
//			 controller: 'firController', 
//			 templateUrl: 'fir.html' 
//		})
//		.when('/fir', {
//			controller: 'secController', 
//		 	templateUrl: 'sec.html' 
//		
//		})
//		.when('/sec', {
//			controller: 'thirController', 
//		 	templateUrl: 'three.html' 
//		})
//		.otherwise({ redirectTo: '/' });
//}]);


$(function(){
	$(".list").each(function(i){
		$(".content").eq(3).css("display","block").siblings().css("display","none");
		$(".btn-item li").eq(3).css("background","rgba(0,0,0,0.3)").siblings().css("background","");
		$(".btn-item li").eq(2).css("background","#1F8EF4");
	});
	$(".list").each(function(i){
		$(this).click(function(){
			if ($(this).index()==0 || $(this).index()==2) {
				$(".main_content .content").eq(i).css("background","black")
				return false;
			}else{
				$(this).css("background","rgba(0,0,0,0.3)").siblings().css("background","");
				$(".main_content .content").eq(i).css("display","block").siblings().css("display","none");
			}
		});
	});
	
	
	//content3
	$(".content:nth-child(3) .table li").click(function(){
		$(this).css({
			'background':'white',
			'color':' #2B7AFB'
		}).siblings().css({
			'background':'',
			'color': 'white'
		});
	});
//重置获取高度
$(document).ready(function(){
var h=document.documentElement.clientHeight;
var h_1=document.documentElement.clientHeight;
  h=h-170;
  h_1=h_1-250;
 $("#rt").css("height",h);
 $("#tc").css("height",h_1);
$(window).resize(function() {
	var  h1=document.documentElement.clientHeight;
	var  h1_1=document.documentElement.clientHeight;
  	h1=h1-170;
  	h1_1=h1_1-250;
 	$("#rt").css("height",h1);
 	$("#tc").css("height",h1_1);
});

});
	//datatables
	var uRl="http://192.168.0.103/pms/servies/two/public/index.php";
	var table=$('#tableInfo').DataTable({
		"columns": [
			{ "data": "mc" },
			{ "data": "sl" },
			{ "data": "zdw" },
			{ "data": "zdkc" },
			{ "data": "zxkc" },
			{ "data": "t_yl_yllx_id" },
			{ "data": "t_yl_ck_id" }
		],
		"searching": false,
		"lengthChange": false,
		"pageLength":10,
		"checkAllId": "employeeCheckAll",
		"paging":true,			//是否显示分页
		"processing":true,			
		"serverSide":true ,     //启动覆盖页分页
		"autoWidth" : true, 	//是否自适应宽度 
		"scrollCollapse": false,
		"paginate" : false,
		"info":false,
		"ajax":{
			"url":uRl+"/yuanliao/ylkucun/index",
			"error":function(jqXHR,textStatus,errorMsg){
			}
		}, 
		"language": {
               "sProcessing": "数据加载中...",
               "sLengthMenu": "显示 _MENU_ 条结果",
               "sInfo": "显示第 _START_ 至 _END_ 项  库存信息，共 _TOTAL_ 条",
               "sInfoEmpty": "显示第 0 至 0 条 库存信息，共 0 条",
               "sLoadingRecords": "载入中...",
               "sInfoThousands": ","
      },
      "createdRow": function ( row, data, index ) {
			$('td', row).eq(0).css({
				'text-align':"center"
			});
			$('td', row).eq(1).css({
				'text-align':"center"
			});
			$('td', row).eq(2).css({
				'text-align':"center"
			});
			$('td', row).eq(3).css({
				'text-align':"center"
			});
			$('td', row).eq(4).css({
				'text-align':"center"
			});
			$('td', row).eq(5).css({
				'text-align':"center"
			});
			$('td', row).eq(6).css({
				'text-align':"center"
			});
			$('td', row).eq(7).css({
				'text-align':"center"
			});
        },
	});
	createList();
	
	//给每一个li添加点击事件
	$("#datatables_list").on("click","li",function(){
		var data=$(this).attr("class");
		var u=uRl+"/yuanliao/ylkucun/index?id="+data;
		var table = $('#tableInfo').DataTable();
		table.ajax.url(u).load();
	});
	
});
function createList(){
	$.ajax({
		type:"get",
		url:"http://192.168.0.103/pms/servies/two/public/index.php/yuanliao/cangku/index1",
		async:true,
		success:function(data){
			var data=data.result.data;
			for (var i = 0; i < data.length; i++) {
				$("#datatables_list").append("<li class="+data[i].id+">"+data[i].mc+"</li>");
			}
		}
	});
}