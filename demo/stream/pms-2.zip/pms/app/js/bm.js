$(function(){
	var getYuangongId=id_name;
	$("input[name='ssid']").val(ssid);
	if(getYuangongId=="" || getYuangongId==undefined){
		ajaxurl="/renyuan/bm/add?lx=1";
		$("#showModal1 #myModalLabel").html("新增部门信息");
		sele()
	}else{
		ajaxurl="/renyuan/bm/one_info";
		$("#showModal1 #myModalLabel").html("修改部门信息");
		one_info()
	}
//	------------------------添加
var html1="";
var str="";
function aa(datal,info){
	for(var i=0;i<datal.length;i++){
	 	var id=datal[i].id;
	 	var mc=datal[i].name;
	 	if(info!=0){
	 		if(info.ssid==id){
	 			return mc;
	 		}else{
	 			if(datal[i].children!=null){
			        aa(datal[i].children,info);
		         }
	 		}
	 	}
		
	}
}
function sele(){
	$.ajax({
		type:"get",
		dataType:"json",
		url:uRl+ajaxurl,
		success:function(data){
            var bumen=data.result.bumen;
            aa(bumen,0);
            $("[name=ssid]").html(html1);
             $("body").mLoading('hide');
            html1="";
            str="";
        }
	});
}
//修改追加数据 ;
	function one_info(){
		$.ajax({
		type:'get',
   		dataType:"json",
   		asyn:false,
   		beforeSend:function(){
   			 console.log("开始发送");
   		},
   		data:{id:getYuangongId,lx:1},
		url:uRl+ajaxurl,
		success:function(data){
			if(data.status==1){
				console.log(data);
				var bumen=data.result.bumen;
				resstr=data.result.info;
                 var mc=aa(bumen,resstr)
                 if(mc==""||mc==null){
                 	mc="一级部门";
                 	resstr.ssid=0;
                 }
                $("#cbad").val(mc);
                $("#ssid").val(resstr.ssid);
                $("[name=mc]").val(resstr.mc);
                 $("body").mLoading('hide');
                html1="";
                str="";
			}else if(data.status==0){
				notify(data.err_msg,"danger");
			}
		}
	})
	}
//	-------------------点击提交-------------------------------
	
})//end
