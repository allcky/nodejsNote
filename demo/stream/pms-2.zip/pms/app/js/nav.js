$(function () {
    //点击顶部导航栏左侧变化
    $("body").on("click",".one",function () {
        $(".sidebar .nav .side-tab").addClass("hide");
        $(this).removeClass("hide");
        $(this).addClass("expanded");
        // $(this).find("a").next("ul").
        /*console.log($(this));
        var flag = true;
        $(this).click(function () {
            $(".sidebar .nav .side-tab").each(function (s) {
                $(".sidebar .nav .side-tab")[s].style.display = "none";

                $(".sidebar .nav .side-tab").each(function (i) {
                    $($(".sidebar .nav .side-tab")[i].children[0]).next("ul").removeClass("collapse").addClass("expanded").css("height", "auto");
                    $(".sidebar .nav .side-tab")[i].children[0].style.display = "none";

                })
            });
            $(".sidebar .nav .side-tab").siblings().removeClass("hide");

            $(".sidebar .nav .side-tab")[index + 1].style.display = "block";
            $(this).addClass('active_tab').find("a").css("color", "white");
            $(this).siblings('li').removeClass('active_tab');

        })*/
    })

    /*顶部导航栏点击时侧边子元素出现*/
/*    $(".one").each(function (index) {
        var flag = true;
        $(this).click(function () {
            $(".sidebar .nav .side-tab").each(function (s) {
                $(".sidebar .nav .side-tab")[s].style.display = "none";

                $(".sidebar .nav .side-tab").each(function (i) {
                    $($(".sidebar .nav .side-tab")[i].children[0]).next("ul").removeClass("collapse").addClass("expanded").css("height", "auto");
                    $(".sidebar .nav .side-tab")[i].children[0].style.display = "none";

                })
            });
            $(".sidebar .nav .side-tab").siblings().removeClass("hide");

            $(".sidebar .nav .side-tab")[index + 1].style.display = "block";
            $(this).addClass('active_tab').find("a").css("color", "white");
            $(this).siblings('li').removeClass('active_tab');

        })
    })*/
    /*点击图标时回到首页*/

   /* $(".brand-logo")[0].onclick = function () {
        $(".sidebar .nav .side-tab").each(function (i) {
            $(".sidebar .nav .side-tab")[i].children[0].style.display = "block";
            $($(".sidebar .nav .side-tab")[i].children[0]).next("ul").removeClass("expanded").addClass("collapse").removeClass("show");
        });
        $(".sidebar .nav .side-tab").find("a").eq(0).removeClass("hide");
        $(".sidebar .nav .side-tab").siblings().removeClass("hide");
    }*/
})


/*导航栏图标颜色变化*/
/*
$(".iconColor").hover(function () {
    $(this).find('em').css("color", "#515253");
}, function () {
    $(this).find('em').css("color", "#fff");

})*/
