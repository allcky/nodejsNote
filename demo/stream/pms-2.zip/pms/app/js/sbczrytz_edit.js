$(function(){
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		sele("add");
		$("#myModalLabel").html("添加设备台账管理");
	} else {
		sele("one_info",getYuangongId);
		$("#myModalLabel").html("修改设备台账管理信息");
	}
	function creatData(data,dataid){
		var html="<option>请选择操作人员</option>";
		if(dataid){
			$.each(data, function(i,e) {
				if(dataid==e.id){
					html+="<option  value="+e.id+" selected>"+e.xm+"</option>";
				}else{
					html+="<option  value="+e.id+">"+e.xm+"</option>";
				}
		    });
		}else{
			$.each(data, function(i,e) {
					html+="<option  value="+e.id+">"+e.xm+"</option>";
		    });
		}
		
		$("[name=user_id]").html(html);
	}
	function creatData1(data,dataid){
		var html="<option>请选择设备信息</option>";
		if(dataid){
			$.each(data, function(i,e) {
				if(dataid==e.id){
					html+="<option  value="+e.id+" selected>"+e.name+"</option>";
				}else{
					html+="<option  value="+e.id+">"+e.name+"</option>";
				}
		    });
		}else{
			$.each(data, function(i,e) {
				html+="<option  value="+e.id+">"+e.name+"</option>";
		    });
		}
		$("[name=info_id]").html(html);
	}
	////////////添加获取数据
	function sele(action,dataid) {
		var urlTj;
		if(dataid){
			urlTj=uRl + "/info/userflow/"+action+"?id="+dataid;
		}else{
		   urlTj=uRl + "/info/userflow/"+action;	
		}
		$.ajax({
			type: "get",
			dataType: "json",
			url: urlTj,
			success:function(data){
				$("body").mLoading('hide');
//				console.log(data);
				var one_info=data.result.one_info//一条数据
				var info=data.result.info;
				var userlist=data.result.userlist;
				if(one_info){
					creatData1(info,one_info.info_id);
					creatData(userlist,one_info.user_id);
				}else{
					creatData1(info);
					creatData(userlist);
				}
	        }
		});
	}
	
	

})//end
