$.ajaxSetup({
	"type":"post",
	dataType:"json",
	asnc:false,
	error:function(data,status,msg){
		console.log("错误信息");
	}
});
//分页
$(function(){
	function addList(){

	}
	$.ajax({
		url:uRl+"/renyuan/yuangong/index?lx=2",
		success:function(data){
			console.log(data);
			var counts=data.result.counts;
			var	data_len=data.result.list.length;	
			//清除缓存
			// localStorage.clear();
			var id_arr=[];
			for (var i = 0; i < data_len; i++) {
				var id=data.result.list[i].id;
				var tx=data.result.list[i].tx;
				if(tx==""){
					tx="app/img/pms_logo.png"
				}else{
					tx=uRl_up+data.result.list[i].tx;
				}
	   			
			}



			//添加缓存
			// id_arr.push(id);
			// localStorage.setItem("id",id_arr);
			//全选
			$("#yuanGongTable").on("change",".checkbox input:eq(0)",function(){
				var num=$(this).index();
				if($(this).get(0).checked){
					 $(".checkbox input").each(function (index) {
		                $(".checkbox input").not(":eq("+num+")").prop("checked",true);
		            })
				}else{
					$(".checkbox input").each(function (index) {
		                $(".checkbox input").not(":eq("+num+")").prop("checked",false);
		            })
				};
			});
			//监听是否选中
			$("#yuanGongTable").on("change",".checkbox input",function(){
				var obj = $(".checkbox input");
				var count = obj.length-1;
				var selectCount = 0;
				for(var i = 1; i <=count; i++) {
					if(obj[i].checked) {
						selectCount++;
					}
				}
				if(count == selectCount) {
					 $(".checkbox input").eq(0).prop("checked",true);
				} else {
					 $(".checkbox input").eq(0).prop("checked",false);
				}
			});
////			---------------分页------------------------
//		    //回调函数的作用是显示对应分页的列表项内容
//		    //回调函数在用户每次点击分页链接的时候执行
//		    //参数page_index{int整型}表示当前的索引页
		    var initPagination = function() {
		        var num_entries = Math.ceil(counts/10);
		        // 创建分页
		        $("#Pagination").pagination(num_entries, {
		            num_edge_entries: 3, //边缘页数
		            num_display_entries: 3, //主体页数
		            callback: pageselectCallback,
		            items_per_page:1 //每页显示1项
		        });
		    }();
		
		    function pageselectCallback(page_index, jq){
		        var new_content = $("#hiddenresult div.result:eq("+page_index+")").clone();
		        $("#Searchresult").empty().append(new_content); //装载对应分页的内容
		        	$.ajax({
						url:uRl+"/renyuan/yuangong/index?lx=2",
						data:{page:page_index},
						success:function(data){
							var data_len=data.result.list.length;
							var old='<tr>'+
									'<td style="display:none;">id</td>'+
							  		'<td class="check fir">'+
					                    '<div class="checkbox group">'+
					                        '<label>'+
					                            '<input type="checkbox">'+
					                            '<i class="input-helper"></i>'+
					                       ' </label>'+
					                    '</div>'+
					                '</td>'+
					                '<td>照片</td>'+
					                '<td>姓名</td>'+
					               ' <td>性别</td>'+
					               ' <td>出生日期</td>'+
					               ' <td>参加工作日期</td>'+
					                '<td>岗位</td>'+
					               ' <td>职务</td>'+
					               ' <td>部门</td>'+
					               ' <td>是否在岗</td>'+
					               ' <td>联系方式</td>'+
					               ' <td>操作</td>'+
					           ' </tr>';
							$("#yuanGongTable tbody").html(old);
							var str;
							for (var i = 0; i < data_len; i++) {
								var id=data.result.list[i].id;
								var tx=data.result.list[i].tx;
								if(tx==""){
									tx="app/img/pms_logo.png"
								}else{
									tx=uRl_up+data.result.list[i].tx;
								}
								var sfzg=data.result.list[i].sfzg;
								if(sfzg=="1"){
									sfzg="是";
								}else{
									sfzg="否";
								}
								data.result.list[i].csrq==null ?  str="无": str=data.result.list[i].csrq;
								var html= '<tr>'+
											'<td style="display:none;">'+data.result.list[i].id+'</td>'+
						   						 '<td class="check">'+
								                    '<div class="checkbox group">'+
									                       '<label>'+
									                            '<input type="checkbox">'+
									                           ' <i class="input-helper"></i>'+
									                       ' </label>'+
									                   ' </div>'+
								                '</td>'+
								                '<td class="td_c"><img class="img" src="'+tx+'" alt=""></td>'+
								                '<td>'+data.result.list[i].xm+'</td>'+
								                '<td>'+data.result.list[i].xb+'</td>'+
								                '<td>'+data.result.list[i].csrq+'</td>'+
								                '<td>'+data.result.list[i].cjgzrq+'</td>'+
								                '<td>'+data.result.list[i].gw_t_sys_mb_id+'</td>'+
								                '<td>'+data.result.list[i].zw_t_sys_mb_id+'</td>'+
								                '<td>'+data.result.list[i].t_yg_bm_id+'</td>'+
								                '<td>'+sfzg+'</td>'+
								                '<td>'+data.result.list[i].lxfs+'</td>'+
								              '  <td>'+
								                   ' <div class="buttons">'+
								                       ' <a class="edit" name="edit" data-id="'+data.result.list[i].id+'" href="#/app/Worker_edit" style="color: #43d967;">'+
								                          '  <em class="fa fa-pencil"></em>'+
								                        '</a>'+
								                      '  <a href="#/app/Worker_chakan" style="color: #2f80e7;">'+
								                          '  <em class="fa fa-eye" style="color:#e1dfe3"></em>'+
								                       ' </a>'+
								                       ' <a class="removeBtn" name=`+id+`  style="color: #f05050;">'+
								                          '  <em class="fa fa-trash"></em>'+
								                      '  </a>'+
								                    '</div>'+
								                '</td>'+
								            '</tr>';
							$(html).appendTo($("#yuanGongTable"));
							}
						}
					});
		        return false;
		    }
		}
	});
});
//删除ajax行数据
$("#yuanGongTable tbody").on("click","tr .removeBtn",function(){
	var parent=$(this).parent().parent().parent();
	var thisId=$(this).parent().parent().parent().children()[0].innerText;   //获取id

	$.ajax({
				type:"post",
				url:uRl+"/renyuan/yuangong/edit",
				data:{id:thisId},
				success:function(data){
					if(data.status==1){
						notify("删除成功","inverse");
						parent.remove();
					}
				}
			});
});
////删除全部数据
$(".removeAll").click(function(){
	  var idLength= $(".check input").length;
	  var arr_id=[];
	  var eq=[];  //保存删除列的下标
            for(var i=1;i<idLength;i++){

                if( $(".check input")[i].checked){
                    var fid= $(".checkbox input")[i].parentNode.parentNode.parentNode.parentNode.childNodes[0].innerText;
                    arr_id.push(fid);
                    eq.push(i);
                }

            }

            if(arr_id==''){notify("请选择要删除的数据","danger");return}
            $.ajax({
					type:"post",
						url:uRl+"/renyuan/yuangong/delete",
						data:{ids:arr_id},
						success:function(data){

							if(data.status==1){
								for(var r=0;r<eq.length;r++){
                            	$(".checkbox input")[eq[r]].parentNode.parentNode.parentNode.parentNode.setAttribute("style","display:none");
                       			}
                       			arr_id="";
                       			eq="";
								// parent.remove();
								// console.log("删除成功");
							}
						}
				});
           
	//判断是否选中按钮
// 	var obj = $(".checkbox input");
// 	var count = obj.length-1;
// 	var selectCount = 0;
// 	for(var i = 1; i <=count; i++) {
// 		if(obj[i].checked) {
// 			selectCount++;
// 		}
// 	}
// 	if(count == selectCount) {
// 		//获取所有id,添加到数组里面
// //		var arr_id=[];
// 		var arr_id=new Array();
// 		$(".removeBtn").each(function(n){
// 			arr_id.push($(".removeBtn").eq(n).attr("name"));
// 		});
// 		//调用ajax删除全部
// 		if($(".sweet-overlay")[0].style.display=="none"){
// 			$(".sweet-overlay").show();
// 			$(".sweet-alert").slideDown(500);
// 			//禁止滚动条
// 			 $(document.body).css({
// 			   "overflow-x":"hidden",
// 			   "overflow-y":"hidden"
// 			 });
// 			$(".confirm").click(function(){
// 				$.ajax({
// 					type:"post",
// 						url:uRl+"/renyuan/yuangong/delete",
// 						data:{ids:arr_id},
// 						success:function(data){
// 							if(data.status==1){
// 								parent.remove();
// //								location.reload();
// 								console.log("删除成功");
// 							}
// 						}
// 				});
// 				$(".sweet-overlay").hide();
// 					//启用滚动条
// 					 $(document.body).css({
// 					   "overflow-x":"auto",
// 					   "overflow-y":"auto"
// 					 });
// 			});
// 			$(".cancel").click(function(){
// 				$(".sweet-overlay").hide();
// 				//启用滚动条
// 				 $(document.body).css({
// 				   "overflow-x":"auto",
// 				   "overflow-y":"auto"
// 				 });
// 			});
// 		}
// 	}else{
// 		if($(".zhezhao2")[0].style.display=="none"){
// 			$(".zhezhao2").show();
// 			$(".weixuanzhong").slideDown(500);
// 			//禁止滚动条
// 			 $(document.body).css({
// 			   "overflow-x":"hidden",
// 			   "overflow-y":"hidden"
// 			 });
// 			$(".confirm").click(function(){
// 				$(".zhezhao2").hide();
// 				//启用滚动条
// 				 $(document.body).css({
// 				   "overflow-x":"auto",
// 				   "overflow-y":"auto"
// 				 });
// 			});
// 		}	
// 	}
});
$("#yuanGongTable tbody").on("click",".edit",function(){
	
	// var getYuangongId=localStorage.getItem("id");
	var thisId=$(this).attr("data-id");  //获取选择修改的id

	//拆分字符串
	// getYuangongId=getYuangongId.split(",");
			// localStorage.clear();
			localStorage.setItem("edit_id",thisId);  //保存修改id；

			location.href="#/app/Worker_edit";
});



if(localStorage.getItem("edit_id")){
			       		localStorage.removeItem("edit_id")//请求成功后 清空 修改id
			       	}
