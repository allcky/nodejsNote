$(function(){
	var getYuangongId=localStorage.getItem("edit_id");
	$("input[name='id']").val(getYuangongId);
	function creatData(data,dataid){
		var html="";
		var html2="";
		if(dataid){
			$.each(data, function(i,e) {
				if(dataid==e.id){
					html+="<option  value="+e.id+" selected>"+e.mc+"<input type='text' name='sl"+i+"'/>"+"</option>";
				}else{
					html+="<option  value="+e.id+">"+e.mc+"<input type='text' name='sl"+i+"'/>"+"</option>";
				}
			});
		}else{
			$.each(data, function(i,e) {
				// html2+="<input type='text' name='sl"+i+"'/>";
				html+="<option value='"+e.id+"' sl='' onclick='vv($(this),$(this).val())'>"+e.mc+html2+"</option>";
			});
		}
		$("#t_yl_yl_id").html(html);
	}
	function sele(r){
		$.ajax({
			type:"get",
			dataType:"json",
			url:uRl+"/yuanliao/cplx/"+r,
			success:function(data){
				console.log(data);
				var yl=data.result.yl;//库存类表
				var info=data.result.info//一条信息
				if(info){
					creatData(yl,info);
				}else{
					creatData(yl);
				}

			}
		});
	}
//	------------------------
	if(getYuangongId==''||getYuangongId==null){  //如果存在修改id 则执行修改函数追加书数据
		sele('add')
		$("#mb_xx").text("成品类型录入");
	}else{
		sele("edit?id"+getYuangongId);
		$("#mb_xx").text("成品类型修改");
	}
////	-------------------点击提交-------------------------------
})//end
var obj;
function vv(ww,qq){
	obj=ww;
	var val=qq;
	var html22=obj.html();
	var attr1=obj.attr("sl");
	var sl;
	$("[name=qwer]").css("visibility","");
	if(obj.attr("sl")){
		$("[name=qwer]").val(obj.attr("sl"))
	}else{
		$("[name=qwer]").val("")
	}
	$("[name=qwer]").blur(function () {
		$("[name=qwer]").css("visibility","hidden");
		sl=$("[name=qwer]").val();
		attr1="";
		if(obj.attr("sl")){
			obj[0].childNodes[1].innerText=sl;
		}else{
			obj.html(html22+"&nbsp;&nbsp;&nbsp;数量：<span>"+sl+"</span>");
		}
		obj.attr("sl",sl);

	})
}
