var ssid, value, id_name;
var id_name = "";
var obj = { mc: "名称不能为空", bz: "备注不能为空" };
var tree_js = function() {
	$('#jstree').jstree({
		"core": {
			"animation": 0,
			"check_callback": true,
			"themes": { "stripes": true },
			'dblclick_toggle': false,
			"plugins": ["themes", "html_data"],
			'data': {
				'type': 'get',
				'url': uRl + "/yuanliao/yllx/index",
				'data': function(node) {
					return { 'id': node.id };
				}
			}
		},
		"types": {
			"#": {
				"max_children": 5,
				"max_depth": 11,
				"valid_children": ["root"]
			},
			"root": {
				"icon": "fa fa-folder",
				"valid_children": ["default"]
			},
			"default": {
				"icon": "fa fa-file-o",
				"valid_children": ["default", "file"]
			},
			"file": {
				"icon": "fa fa-file-o",
				"valid_children": []
			}
		},
		"plugins": [
			"contextmenu", "dnd", "search",
			"state", "types", "wholerow"
		]
	});
	$('#jstree').jstree("open_all");
}
$(function() {
	tree_js();
});
$("[name=addInfo]").click(function() {
	id_name = "";
	createLoading("yuanliaoleixingguanli_edit","#showModal1","#showModal2","jz");
});
$("[name=editInfo]").click(function() {
	createLoading("yuanliaoleixingguanli_edit","#showModal1","#showModal2","jz");
})
$("[name=delInfo]").click(function() {
	del();
})
//jstree单击事件  
$("#jstree").bind("select_node.jstree", function(e, data) {
	id_name = data.node.id;
	ssid = data.node.parent;
});
//保存
$("[name=save_button1]").click(function() {

	if(id_name) {
		addedit("edit?id=" + id_name, obj);
	} else {
		addedit("add", obj);
	}
});

function del() {
	$.ajax({
		type: "post",
		url: uRl + "/yuanliao/yllx/delete",
		async: true,
		data: { id: id_name },
		success: function(data) {
			if(data.status == 1) {
				notify(data.result, "success");
				var tree = jQuery.jstree.reference("#jstree");
				tree.refresh();
			} else if(data.status == 0) {
				notify(data.err_msg, "danger");
			}
		}
	});
};
//添加/编辑
function addedit(r, odj) {
	if(odj) {
		for(n in odj) {
			if($("[name=" + n + "]").val() == "" || $("[name=" + n + "]").val() == null) {
				notify(odj[n], "danger");
				return false;
			}
		}
	}
	$.ajax({
		url: uRl + "/yuanliao/yllx/" + r,
		type: 'post',
		dataType: "json",
		asyn: false,
		data: $('#tj').serialize(),
		success: function(data) {
			if(data.status == 1) {
				notify(data.result, "inverse");
				var tree = jQuery.jstree.reference("#jstree");
				tree.refresh();
				$('#showModal1').modal('hide');
			} else if(data.status == 0) {
				notify(data.err_msg, "danger");
				//					console.log("发送失败");
			}
		}
	})
}