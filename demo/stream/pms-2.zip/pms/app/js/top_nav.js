//获取top_nav的五个模块添加class

$(".nav-wrapper .navbar-nav li:gt(0):lt(5)").addClass("mian_module");

////遍历
//$(".mian_module>a").click(function(){
//	$(this).parent().addClass("open").siblings().removeClass("open");
//});



//border显示或者隐藏
$(function(){
	var boo=true;
	$(".nav-wrapper .navbar-nav li:eq(0)").click(function(){
		if(boo){
			 //显示二级导航
	        $(".sidebar .nav .side-tab:gt(0)").show();
	        //显示二级导航下的二级标题
	        $(".sidebar .nav .side-tab:gt(0)").find("a").show();
	        //隐藏三级导航
	        $(".sidebar .nav .side-tab:gt(0)").find("a").next("ul").removeClass("collapse").addClass("expanded").css("height","auto");
			$(".sidebar > .nav > li:nth-child(2)").css("border","none");
			$(".sidebar > .nav > li:nth-child(2)").css("margin-top","20px");
			boo=false;
		}else{
			 //显示二级导航
	        $(".sidebar .nav .side-tab:gt(0)").show();
	        //显示二级导航下的二级标题
	        $(".sidebar .nav .side-tab:gt(0)").find("a").show();
	        //隐藏三级导航
	        $(".sidebar .nav .side-tab:gt(0)").find("a").next("ul").addClass("collapse");
			$(".sidebar > .nav > li:nth-child(2)").css("border-left","3px solid #2F80E7");
			$(".sidebar > .nav > li:nth-child(2)").css("margin-top","-11px");
			boo=true;
		}
	});
	$(".nav-wrapper .nav li").not(":eq(0)").click(function(){
		if(boo==false){
			 //显示二级导航
	        $(".sidebar .nav .side-tab:gt(0)").show();
	        //显示二级导航下的二级标题
	        $(".sidebar .nav .side-tab:gt(0)").find("a").show();
	        //隐藏三级导航
	        $(".sidebar .nav .side-tab:gt(0)").find("a").next("ul").removeClass("collapse").addClass("expanded").css("height","auto");
			$(".sidebar > .nav > li:nth-child(2)").css("border","none");
			$(".sidebar > .nav > li:nth-child(2)").css("margin-top","20px");
		}else{
			$(this).addClass("open").siblings().removeClass("open");
			var aLi=$(".sidebar .nav .side-tab:gt(0)");
			var index=$(this).index();
			aLi.hide();
			aLi.eq(index-1).show();
			aLi.eq(index-1).find("a").eq(0).hide();
			aLi.eq(index-1).find("a").eq(0).next("ul").show();
			aLi.eq(index-1).find("a").eq(0).next("ul").css("margin-top","-11px");
			aLi.eq(index-1).find("a").eq(0).next("ul").removeClass("collapse").css("height","auto");
		}
	})
	//点击图标
	$(".brand-logo").click(function(){
		 //显示二级导航
        $(".sidebar .nav .side-tab:gt(0)").show();
        //显示二级导航下的二级标题
        $(".sidebar .nav .side-tab:gt(0)").find("a").show();
        //隐藏三级导航
        $(".sidebar .nav .side-tab:gt(0)").find("a").next("ul").addClass("collapsed");
	})
	 $("body").on("click"," .sidebar .nav .side-tab a",function(){
	 		$(this).next("ul").addClass("collapsed").removeClass("expanded").css("height","auto");
	 })
	//点击二级一级变化
	$("body").on("click",".sidebar .nav .side-tab",function(){
		var index=$(this).index();
		$(".sidebar .nav .side-tab:gt(0)").find("ul").addClass("collapse");
		$(".mian_module>a").eq(index-1).parent().addClass("open");
		$(".mian_module>a").eq(index-1).parent().siblings().removeClass("open");
	})
});
