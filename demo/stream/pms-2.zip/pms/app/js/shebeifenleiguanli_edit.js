$(function() {
	//日历插件
	$('.form_date').datetimepicker({
		language: 'zh-CN',
		pickerPosition: "bottom-left",
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format: 'yyyy/mm/dd'
	});
	
	
	
	var str = "";
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId==''||getYuangongId==null){  //如果存在修改id 则执行修改函数追加书数据
		$("#myModalLabel").html("设备类型信息");
		$("body").mLoading('hide');
		return false;
	}else{
		$("#myModalLabel").html("修改设备类型");
		zhuijia();
	}
	//修改追加数据  zhuijia();
	function zhuijia() {
		$.ajax({
			type: 'get',
			dataType: "json",
			asyn: false,
			beforeSend: function() {
//				console.log("开始发送");
			},
			data: { id: getYuangongId },
			url: uRl + "/info/infotype/one_info",
			success: function(data) {
				if(data.status == 1) {
					$("input[name='title']").val(data.result.info.title);
					$("textarea[name='content']").val(data.result.info.content);
					$("body").mLoading('hide');
				}else if (data.status==0) {
					console.log("发送失败!")
				}
			}
		})
	}
}) //end