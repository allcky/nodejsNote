var  ssid,value,id_name;
	var id_name="";
	var obj={mc:"名称不能为空"};
	var tree_js=function(){
		$('#jstree').jstree({
			"core": {
				"animation": 0,
				"check_callback": true,
				"themes": { "stripes": true },
				'dblclick_toggle': false,
				"plugins": ["themes", "html_data"],
				'data': {
					'type': 'get',
					'url': uRl + '/renyuan/bm/getbm?lx=2',
					'data': function(node) {
						return { 'id': node.id };
					}
				}
			},
			"types": {
				"#": {
					"max_children": 5,
					"max_depth": 11,
					"valid_children": ["root"]
				},
				"root": {
					"icon": "fa fa-folder",
					"valid_children": ["default"]
				},
				"default": {
					"icon": "fa fa-file-o",
					"valid_children": ["default", "file"]
				},
				"file": {
					"icon": "fa fa-file-o",
					"valid_children": []
				}
			},
			"plugins": [
				"contextmenu", "dnd", "search",
				"state", "types", "wholerow" 
			]
		});
		$('#jstree').jstree("open_all");
	}
	$(function() {
		tree_js();
	});
	$("[name=addInfo]").click(function() {
		id_name="";
		createLoading("zydgl_edit","#showModal1","#showModal2","jz");
		
	});
	$("[name=editInfo]").click(function() {
		createLoading("zydgl_edit","#showModal1","#showModal2","jz");
	})
	$("[name=delInfo]").click(function() {
		del();
	})
	//jstree单击事件  
	$("#jstree").bind("select_node.jstree", function(e, data) {
		id_name=data.node.id;
		ssid=data.node.parent;
	});
	//保存
	$("[name=save_button1]").click(function(){
		if(id_name){
			addedit("edit?id="+id_name,obj);
		}else{
			addedit("add",obj);
		}
		
	});
	function del(){
		Common.confirm({message:"确认删除作业队信息吗？",operate:function(reselt){if(reselt){
			$.ajax({
				type: "post",
				url: uRl + "/renyuan/bm/delete",
				data: { id: id_name },
				success: function(data) {
					if(data.status == 1) {
						notify(data.result, "success");
						var tree = jQuery.jstree.reference("#jstree");
						tree.refresh();
						$('#tableInfo').DataTable().row('.selected').remove().draw( false );
					}else{
						notify(data.err_msg, "danger");
					}
				}
			});
		}}});
	};
	//添加/编辑
	function addedit(r,odj){
		if($("[name=ssid]").val()==""||$("[name=ssid]").val()==null || $("[name=ssid]").val()=="#"){
			$("[name=ssid]").val(0)
		}
		if(odj){
			for(n in odj){
				if ($("[name="+n+"]").val()==""||$("[name="+n+"]").val()==null) {
					notify(odj[n],"danger");
					return false;
				}
			}
		}
		$.ajax({
			url: uRl+"/renyuan/bm/"+r,
	 		type:'post',
	 		dataType:"json",
	 		asyn:false,
		    data:$('#tj').serialize(),
		    success:function(data,teyuangong_submit3xtStatus,jqXHR){
		       if(data.status==1){
       			notify(data.result,"success");
		       	var tree = jQuery.jstree.reference("#jstree");
				tree.refresh();
				$('#showModal1').modal('hide');
				 $("#showModal1").on("hide", function() {
				    $(this).removeData("modal");  
				});  
		       }else if(data.status==0){
		       	notify(data.err_msg,"danger");
		       }
		    }
	    })
	}