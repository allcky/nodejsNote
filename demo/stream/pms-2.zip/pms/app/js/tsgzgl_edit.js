$(function() {
	//日历插件
	$('.form_date').datetimepicker({
		language: 'zh-CN',
		pickerPosition: "bottom-left",
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format: 'yyyy/mm/dd'
	});
	
	///////////////////////////
	var html1 = "<option value='0'>请选择</option>";
	var str = "";

	
	///////////////////////////
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		$("#showModal1 #myModalLabel").html("新增特殊工种信息");
		ajaxurl = "/renyuan/zs/add?lx=2";
		sele();
	} else {
		$("#showModal1 #myModalLabel").html("修改特殊工种信息");
		ajaxurl = "/renyuan/zs/one_info";
		one_info();
	}
	
function aa(datal,info){
	var mc;
	for(var i=0;i<datal.length;i++){
	 	if(info!=0){
	 		if(info==datal[i].id){
	 		  	mc=datal[i].name;
	 		   	if(mc==""||mc==null){
                 	mc="一级部门";
//               	resstr.ssid=0;
                }
                $("#cbad").val(mc);
                $("[name=t_yg_bm_id]").val(datal[i].id);
	 		  return mc;
	 		}else{
	 			if(datal[i].children!=null){
			        aa(datal[i].children,info);
		         }
	 		}
	 	}
		
	}
	
}
	////////////添加获取数据
	function sele() {
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + ajaxurl,
			success: function(data) {
				console.log(data);
				var ry=data.result.userlist;
				$("#t_yg_ry_id").select2({
					tags: false,
					minimumResultsForSearch: -1
			    });
				$.each(ry, function(i, v) {
					$("#t_yg_ry_id").append("<option>请选择工种</option><option value='" + v.id + "'>" + v.xm + "</option>");
				});
				$("body").mLoading('hide');
			}
		});
	}
	//修改追加数据  zhuijia();
	function one_info() {
		$.ajax({
			type: 'get',
			dataType: "json",
			asyn: false,
			beforeSend: function() {
				console.log("开始发送");
			},
			data: { id: getYuangongId, lx: 2 },
			url: uRl + ajaxurl,
			success: function(data) {
				if(data.status == 1) {
					console.log(data);
					var infostr=data.result.info;
					var userlist=data.result.userlist;
					$('[name=zsmc]').val(infostr.zsmc);
					$('[name="fzjg"]').val(infostr.fzjg);
					$('[name="zsdj_t_sys_mb_id"]').val(infostr.zsdj_t_sys_mb_id);
					$('[name="fzrq"]').val(infostr.fzrq);
					$('[name="njrq"]').val(infostr.njrq);
					$('[name="zsbh"]').val(infostr.zsbh);
					$('[name="id"]').val(infostr.id);
					var ry=data.result.userlist;
					$("#t_yg_ry_id").select2({
						tags: false,
						minimumResultsForSearch: -1
				    });
					$.each(ry, function(i, v) {
						if(data.result.info.t_yg_ry_id==v.id){
							$("#t_yg_ry_id").append("<option value='" + v.id + "' selected>" + v.xm + "</option>");
							alert(data.result.info.t_yg_ry_id);
						}else{
							$("#t_yg_ry_id").append("<option value='" + v.id + "'>" + v.xm + "</option>");
						}
						
					});
					var str="";
					if (infostr.zslx==1) {
						str="特种";
					}else if (infostr.zslx==2) {
						str="普通";
					};
					$('[name=zslx]').val(str);
					$("body").mLoading('hide');
				}else if(data.status == 0){
					notify(data.result, "danger");
				} 
				
			},
			complete: function() {
				console.log("接收成功");
			}
		})
	}
}) //end
