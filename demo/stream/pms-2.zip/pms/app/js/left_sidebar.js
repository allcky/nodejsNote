//获取nav 中第一个li元素
var li_fir=$(".sidebar .nav li").eq(0);
