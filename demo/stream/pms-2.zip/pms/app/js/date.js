$(function () {
    $('#datetimepicker1').datetimepicker();
    $('#datetimepicker2').datetimepicker();
    $('#datetimepicker3').datetimepicker();
    $('#datetimepicker4').datetimepicker();
    $('#open1').click(function(){
       var boo=true;
       if(boo){
       	alert("a")
       	 $('#datetimepicker1').datetimepicker('show');
       	 boo=false;
       }else{
       	alert('b')
       	$('#datetimepicker1').datetimepicker('hide');
       	boo=true;
       }
    });
    $('#open2').click(function(){
        $('#datetimepicker2').datetimepicker('show');
    });
    $('#open3').click(function(){
        $('#datetimepicker3').datetimepicker('show');
    });
    $('#open4').click(function(){
        $('#datetimepicker4').datetimepicker('show');
    });
})