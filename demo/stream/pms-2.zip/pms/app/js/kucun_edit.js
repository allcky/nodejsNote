$(function(){
	var getYuangongId=localStorage.getItem("edit_id");
	$("input[name='id']").val(getYuangongId);
	var html1="";
    var str="";
 function aa(datal,info){
	for(var i=0;i<datal.length;i++){
		 	var id=datal[i].id;
		 	var mc=datal[i].text;
		 	var jibie=datal[i].jb;
		 	switch (jibie){
		 		case 1:
			 		str="";
			 			break;
		 		case 2:
			 		str="|——";
			 			break;
		 		case 3:
			 		str="|————";
			 			break;
		 		default:
		 			str="|————————";
			 			break;
		 	}
		 	if(info!=0){
		 		if(info.id==id){
		 			html1 +='<option value="'+id+'" selected>'+str+mc+'</option>';
		 		}else{
		 			html1 +='<option value="'+id+'">'+str+mc+'</option>';
		 		}
		 	}else{
		 		html1 +='<option value="'+id+'">'+str+mc+'</option>';
		 	}
			if(datal[i].children!=null){
				aa(datal[i].children,info);
			}
		 }
		 
	 }
     			 
	function sele(r){
		$.ajax({
			type:"get",
			dataType:"json",
			url:uRl+"/yuanliao/cangku/add",
			 success:function(data){
	          	var bm=data.result.bm;
	            aa(bm,0);
	            $("[name=t_yg_bm_id]").html(html1);
	            if(r==1){
	            	$("[name='t_yg_bm_id']").chosen();
	            }
	        }
		});
	}


//	------------------------
	if(getYuangongId==''||getYuangongId==null){  //如果存在修改id 则执行修改函数追加书数据
		sele('1')
		addedit("add");
		$("#mb_xx").text("员工信息录入");
	}else{
		sele('0');
		zhuijia();
		addedit("edit?id="+getYuangongId);
		$("#mb_xx").text("员工信息修改");
	}


////修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
			type:'get',
	   		dataType:"json",
	   		asyn:false,
	   		beforeSend:function(){
	   			 console.log("开始发送");
	   		},
	   		data:{id:getYuangongId},
			url:uRl+"/yuanliao/cangku/one_info",
			success:function(data){
				console.log(data);
				if(data.status==1){
					$("[name=mc]").val(data.result.info.mc);
					aa(data.result.bm,data.result.info.t_yg_bm_id);
					
				
	          };
			},complete:function(){
				console.log("接收成功");
			}
		})
	}

//	-------------------点击提交-------------------------------

	function addedit(r){
		
		$("#saveYuanGongInfo").click(function(){
		var xb=$('input:radio[name="xb"]:checked').val();
		var sfzg=$('input:radio[name="sfzg"]:checked').val();
		if($("input[name=mc]").val()==""){
			notify("仓库名称不能空!", "inverse");
		}else{
			$.ajax({
				url: uRl+"/yuanliao/cangku/"+r,
		 		type:'post',
		 		dataType:"json",
		 		asyn:false,
			    data:$('#yuangong_submit3').serialize(),
			    success:function(data,textStatus,jqXHR){
			       	console.log(data)
			       	if(localStorage.getItem("edit_id")){
			       		localStorage.removeItem("edit_id")//请求成功后 清空 修改id
			       	}
			       if(data.status==1){
			       	console.log("发送成功");
			      	location.href="#/app/singleview2";
			       }
			       if(data.status==0){
			       	console.log("发送失败");
			       }
			    }
		    })
		}
			// localStorage.clear();
	   })
	}
})//end
