$(function() {
	//日历插件
	$('.form_date').datetimepicker({
		language: 'zh-CN',
		pickerPosition: "bottom-left",
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format: 'yyyy/mm/dd'
	});
	
	///////////图片上传预览  结束。
	
	
	
	
	///////////////////////////
	var html1 = "<option value='0'>请选择</option>";
	var str = "";

	
	///////////////////////////
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		$("#showModal1 #myModalLabel").html("新增作业队信息");
		ajaxurl = "/renyuan/yuangong/add?lx=1";
		sele();
	} else {
		$("#showModal1 #myModalLabel").html("修改作业队信息");
		ajaxurl = "/renyuan/yuangong/one_info";
		one_info();
	}
	
function aa(datal,info){
	var mc;
	for(var i=0;i<datal.length;i++){
	 	if(info!=0){
	 		if(info==datal[i].id){
	 		  	mc=datal[i].name;
	 		   	if(mc==""||mc==null){
                 	mc="一级部门";
                 	resstr.ssid=0;
                }
                $("#cbad").val(mc);
                $("[name=t_yg_bm_id]").val(datal[i].id);
	 		  return mc;
	 		}else{
	 			if(datal[i].children!=null){
			        aa(datal[i].children,info);
		         }
	 		}
	 	}
		
	}
	
}
$("[name=sczj]").click(function() {
	$("#zbModal").find(".modal-body").load('app/views/upload.html?time='+new Date().getSeconds());
	$("#zbModal").modal('show');
});
	////////////添加获取数据
	function sele() {
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + ajaxurl,
			success: function(data) {
//				console.log(bumen);
				var gw = data.result.gwmb;
				var zw = data.result.zwmb;
				//岗位
				$("#gw_t_sys_mb_id").select2({
					tags: false,
					minimumResultsForSearch: -1
			    });
				$.each(gw, function(i, v) {
					$("#gw_t_sys_mb_id").append("<option value='" + v.id + "'>" + v.mc + "</option>");
				});
				//职务
				$("#zw_t_sys_mb_id").select2({
					tags: false,
					minimumResultsForSearch: -1
			    });
				$.each(zw, function(i, v) {
					$("#zw_t_sys_mb_id").append("<option value='" + v.id + "'>" + v.mc + "</option>");
				});
				str = "";
				$("body").mLoading('hide');
			}
		});
	}
	//修改追加数据  zhuijia();
	function one_info() {
		$.ajax({
			type: 'get',
			dataType: "json",
			asyn: false,
			beforeSend: function() {
				console.log("开始发送");
			},
			data: { id: getYuangongId, lx: 1 },
			url: uRl + ajaxurl,
			success: function(data) {
				if(data.status == 1) {
				var	resstr = data.result.user_info;
					//改变图像地址
					if(resstr.tx == "" || resstr.tx == null) {
						txstr = "app/img/pms_logo.png";
						$("#preview2").html($("#preview1").html()+"<img src="+txstr+"  width=50 height=50  style='border-radius: 5px;cursor: pointer;vertical-align: bottom;'>");
					} else {
						var imgstr=resstr.tx;
						var imgarr=imgstr.split(",");
						for(var i=0;i<imgarr.length;i++){
							if(imgarr[i]!=""){
								$("#preview2").append("<img src=servies/two/public"+imgarr[i]+"  width=50 height=50  style='border-radius: 5px;cursor: pointer;vertical-align: bottom;'>");
							}
						}
						$("[name='tx']").val(imgstr);
					}
					$("[name='xm']").val(resstr.xm);
					//单选框赋值
					if(data.result.user_info.xb == "男") {
						$('#tj [name=xb]')[0].checked = "checked";
					} else if(data.result.user_info.xb == "女") {
						$('#tj [name=xb]')[1].checked = "checked";
					}
					$("[name='csrq']").val(resstr.csrq);
					$("[name='cjgzrq']").val(resstr.cjgzrq);
					$("[name='zyjszc']").val(resstr.zyjszc);
					$("[name='prsj']").val(resstr.prsj);

	                
	                var bumen=data.result.bumen;
				
                 	var mc=aa(bumen,resstr.t_yg_bm_id)
               
					var gw = data.result.gwmb;
					var zw = data.result.zwmb;
					var str2 = '<option value="0">请选择</option>';
					var str3 = '<option value="0">请选择</option>';
					$.each(gw, function(i, v) {
						if(resstr.gw_t_sys_mb_id == v.id) {
							str2 += "<option value='" + v.id + "' selected>" + v.mc + "</option>"
						} else {
							str2 += "<option value='" + v.id + "'>" + v.mc + "</option>"
						}

					});
					$.each(zw, function(i, v) {
						if(resstr.zw_t_sys_mb_id == v.id) {
							str3 += "<option value='" + v.id + "' selected>" + v.mc + "</option>"
						} else {
							str3 += "<option value='" + v.id + "'>" + v.mc + "</option>"
						}
					});
					
					
					$("[name='gw_t_sys_mb_id']").html(str2);
					$("[name='zw_t_sys_mb_id']").html(str3);
					str2 = "";
					str3 = "";
					html1 = "";
					str = "";
					//单选框赋值
					if(data.result.user_info.sfzg == "1") {
						$('#tj [name=sfzg]')[0].checked = "checked";
					} else if(data.result.user_info.xb == "0") {
						$('#tj [name=sfzg]')[1].checked = "checked";
					}
					$("[name='lxfs']").val(resstr.lxfs);
					$("[name='sczy']").val(resstr.sczy);
					$("[name='xjzd']").val(resstr.xjzd);
					$("[name='xgtd']").val(resstr.xgtd);
					$("[name='bz']").val(resstr.bz);
					$("[name='lx']").val(resstr.lx);
					$("[name='tx']").val(resstr.tx);
					$("[name='id']").val(resstr.id);
					$("body").mLoading('hide');
				}else if(data.status == 0){
					notify(data.result, "inverse");
				} 
				
			},
			complete: function() {
				console.log("接收成功");
			}
		})
	}
}) //end
