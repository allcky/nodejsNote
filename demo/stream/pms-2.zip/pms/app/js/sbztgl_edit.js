$(function(){
	//日历插件
	$('.form_date').datetimepicker({
		language: 'zh-CN',
		pickerPosition: "bottom-left",
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format: 'yyyy-mm-dd'
	});
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		sele("add");
		$("#myModalLabel").html("添加设备账台信息");
	} else {
		sele("one_info",getYuangongId);
		$("#myModalLabel").html("修改账台信息");
	}
	function creatData1(data,dataid){
		var html="<option>请选择设备信息</option>";
		if(dataid){
			$.each(data, function(i,e) {
				if(dataid==e.id){
					html+="<option  value="+e.id+" selected>"+e.title+"</option>";
				}else{
					html+="<option  value="+e.id+">"+e.title+"</option>";
				}
		    });
		}else{
			$.each(data, function(i,e) {
					html+="<option  value="+e.id+">"+e.title+"</option>";
		    });
		}
	
		$("[name=type]").html(html);
	}
	////////////添加获取数据
	function sele(action,dataid) {
		var urlTj;
		if(dataid){
			urlTj=uRl + "info/infotz/"+action+"?id="+dataid;
		}else{
		   urlTj=uRl + "info/infotz/"+action;	
		}
		$.ajax({
			type: "get",
			dataType: "json",
			url: urlTj,
			success:function(data){
//				console.log(data);
				$("body").mLoading('hide');
				var one_info=data.result.info;//一条数据
				var type2=data.result.type;
				if(one_info){
					console.log(one_info);
					$("[name=bianhao]").val(one_info.bianhao);
					$("[name=xinghao]").val(one_info.xinghao);
					$("[name=name]").val(one_info.name);
					$("[name=changjia]").val(one_info.changjia);
					$("[name=c_datetime]").val(one_info.c_datetime);
					$("[name=action]").val(one_info.action);
					$("[name=a_danwei]").val(one_info.a_danwei);
					$("[name=j_time]").val(one_info.j_time);
					$("[name=t_time]").val(one_info.t_time);
					$("[name=status_text]").val(one_info.status_text);
					$("[name=s_danwei]").val(one_info.s_danwei);
					$("[name=z_name]").val(one_info.z_name);
					$("[name=is_te]").each(function(i){
						if ($("[name=is_te]").eq(i).val()==one_info.is_te) {
							$("[name=is_te]").eq(i).attr("checked","checked");
						}
					})
					creatData1(type2,one_info.type);
				}else{
					creatData1(type2);
				}
	        }
		});
	}
})//end
