/**
 * Created by rt on 2017/3/29.
 */
function aaaa() {
    $.ajax({
        data:$('#form').serialize(),
        url: uRl+"/renyuan/waichu/add",
        success:function(data,textStatus,jqXHR){
            if(jqXHR.status==200){
                location.href = "#/app/waichuguanli";
            }else if(jqXHR.status==404){
                alert("页面未找到！");
            }else if(jqXHR.status==500){
                alert("服务器发生错误！")

            }else if(jqXHR.status!=200){
                alert("您的页面走丢了！");
            }

        }
    })
};

