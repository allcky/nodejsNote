$.ajaxSetup({
	"type":"post",
	dataType:"json",
	asnc:false,
	error:function(data,status,msg){
		console.log("错误信息");
	}
});
//分页
$(function(){
	function addlist(){
	$.ajax({
		url:uRl+"/yuanliao/gys/index",
		success:function(data){
			var counts=data.result.counts;
			var	data_len=data.result.list.length;	
			$("#yuanGongTable").on("change",".checkbox input:eq(0)",function(){
				var num=$(this).index();
				if($(this).get(0).checked){
					 $(".checkbox input").each(function (index) {
		                $(".checkbox input").not(":eq("+num+")").prop("checked",true);
		            })
				}else{
					$(".checkbox input").each(function (index) {
		                $(".checkbox input").not(":eq("+num+")").prop("checked",false);
		            })
				};
			});
			//监听是否选中
			$("#yuanGongTable").on("change",".checkbox input",function(){
				var obj = $(".checkbox input");
				var count = obj.length-1;
				var selectCount = 0;
				for(var i = 1; i <=count; i++) {
					if(obj[i].checked) {
						selectCount++;
					}
				}
				if(count == selectCount) {
					 $(".checkbox input").eq(0).prop("checked",true);
				} else {
					 $(".checkbox input").eq(0).prop("checked",false);
				}
			});
////			---------------分页------------------------
//		    //回调函数的作用是显示对应分页的列表项内容
//		    //回调函数在用户每次点击分页链接的时候执行
//		    //参数page_index{int整型}表示当前的索引页
		    var initPagination = function() {
		        var num_entries = Math.ceil(counts/10);
		        // 创建分页
		        $("#Pagination").pagination(num_entries, {
		            num_edge_entries: 3, //边缘页数
		            num_display_entries: 3, //主体页数
		            callback: pageselectCallback,
		            items_per_page:1 //每页显示1项
		        });
		    }();
		
		    function pageselectCallback(page_index, jq){
		        var new_content = $("#hiddenresult div.result:eq("+page_index+")").clone();
		        $("#Searchresult").empty().append(new_content); //装载对应分页的内容
		        	$.ajax({
						url:uRl+"/yuanliao/gys/index",
						data:{page:page_index},
						success:function(data){
							console.log(data)
							var data_len=data.result.list.length;
							var html='<tr>'+
									'<td style="display:none;">id</td>'+
							  		'<td class="check fir">'+
					                    '<div class="checkbox group">'+
					                        '<label>'+
					                            '<input type="checkbox">'+
					                            '<i class="input-helper"></i>'+
					                       ' </label>'+
					                    '</div>'+
					                '</td>'+
					                '<td>供应商名称</td>'+
					                '<td>联系人</td>'+
					               ' <td>联系电话</td>'+
					               ' <td>电子邮件</td>'+
					               ' <td>操作</td>'+
					           ' </tr>';
							$("#yuanGongTable tbody").html(html);
							var str;
							for (var i = 0; i < data_len; i++) {
								html+='<tr>'+
												'<td style="display:none;">'+data.result.list[i].id+'</td>'+
						   						 '<td class="check">'+
								                    '<div class="checkbox group">'+
									                       '<label>'+
									                            '<input type="checkbox">'+
									                           ' <i class="input-helper"></i>'+
									                       ' </label>'+
									                   ' </div>'+
								                '</td>'+
								                '<td>'+data.result.list[i].mc+'</td>'+
								                '<td>'+data.result.list[i].lxr+'</td>'+
								                '<td>'+data.result.list[i].lxdh+'</td>'+
								                '<td>'+data.result.list[i].dzyj+'</td>'+
								              '  <td>'+
								                   ' <div class="buttons">'+
								                       ' <a class="edit" name="edit" href="#/app/gongyingshang_edit" style="color: #43d967;">'+
								                          '  <em class="fa fa-pencil"></em>'+
								                        '</a>'+
								                      '  <a href="#/app/gongyingshang_edit" style="color: #2f80e7;">'+
								                          '  <em style="color:#e1dfe3" class="fa fa-eye"></em>'+
								                       ' </a>'+
								                       ' <a class="removeBtn" name="'+data.result.list[i].id+'"  style="color: #f05050;">'+
								                          '  <em class="fa fa-trash"></em>'+
								                      	'</a>'+
								                    '</div>'+
								                '</td>'+
								            '</tr>';
							}
							
							$(html).appendTo($("#yuanGongTable"));
						}
					});
		        return false;
		    }
		}
	});
	}//ajax()end
	addlist();

});  //end
//删除ajax行数据
$("#yuanGongTable").on("click",".removeBtn",function(){
	var parent=$(this).parent().parent().parent();
	var thisId=$(this).parent().parent().parent().children()[0].innerText;   //获取id
	$.ajax({
		type:"post",
		url:uRl+"/yuanliao/gys/delete",
		data:{id:thisId},
		success:function(data){
			if(data.status==1){
				notify("删除成功","inverse");
				parent.remove();
			}
		}
	});
});
////删除全部数据
$(".removeAll").click(function(){
	  var idLength= $(".check input").length;
	  var arr_id=[];
	  var eq=[];  //保存删除列的下标
            for(var i=1;i<idLength-2;i++){
                if( $(".check input")[i].checked){
                    var fid= $(".check input")[i].parentNode.parentNode.parentNode.parentNode.childNodes[0].innerText;
                    arr_id.push(fid);
                    eq.push(i);
                }
            }
            if(arr_id==''){
            	notify("请选择要删除的数据","inverse");
            	return;
            }else{
				$.ajax({
					type:"post",
					url:uRl+"/yuanliao/gys/delete",
					data:{ids:arr_id},
					success:function(data){

						if(data.status==1){
							for(var r=0;r<eq.length;r++){
                        	$(".checkbox input")[eq[r]].parentNode.parentNode.parentNode.parentNode.setAttribute("style","display:none");
                   			}
                   			arr_id="";
                   			eq="";
                   			notify("数据删除成功","inverse");
							// parent.remove();
							// console.log("删除成功");
						}
					}
				});
            	
            }
            
   
});
$("#yuanGongTable").on("click",".edit",function(){
	
	// var getYuangongId=localStorage.getItem("id");
	var thisId=$(this).parent().parent().parent().children()[0].innerText;  //获取选择修改的id

	//拆分字符串
	// getYuangongId=getYuangongId.split(",");
			// localStorage.clear();
		localStorage.setItem("edit_id",thisId);  //保存修改id；

		location.href="#/app/gongyingshang";
});



if(localStorage.getItem("edit_id")){
	localStorage.removeItem("edit_id")//请求成功后 清空 修改id
			       	}
