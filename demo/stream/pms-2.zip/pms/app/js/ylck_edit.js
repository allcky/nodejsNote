$(function(){
 ///////////////////////////
	var html1="<option value='0'>请选择</option>";
	function aa(data,dataid){
		$.each(data,function(i,v){
			if(dataid){
              if(dataid==v.id){
				  html1+="<option value='"+v.id+"' selected>"+v.mc+"</option>";
			  }else{
				  html1+="<option value='"+v.id+"'>"+v.mc+"</option>";
			  }
			}else{
				html1+="<option value='"+v.id+"'>"+v.mc+"</option>";
			}
		})
	}
	var getYuangongId =localStorage.getItem("id");
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		ajaxurl = "/yuanliao/ylruku/add";
		sele();
		$("#myModalLabel").text("原料入库信息");
	} else {
		ajaxurl = "/yuanliao/ylruku/one_info";
		/*zhuijia();*/
		$("#myModalLabel").text("修改入库信息");
	}
	////////////添加获取数据
	function sele(){
		$.ajax({
			type:"get",
			dataType:"json",
			url:uRl+"/yuanliao/Ylchuku/add",
			 success:function(data){

				 var yl=data.result.yl//所有原料库存集合
				 aa(yl);
				 $("[name=t_yl_yl_id]").html(html1);
				 html1="<option value='0'>请选择</option>";
				 var sgbw=data.result.sgbw//所有施工部位集合
				 aa(sgbw);
				 $("[name=t_xm_sgbw_id]").html(html1);
				 html1="<option value='0'>请选择</option>";
				 var ylph=data.result.ylph//所有原料批号集合s
				 var html2="<option value='0'>请选择</option>";
				 $.each(ylph,function(i,v){
					 html2+="<option value='"+v.id+"'>"+v.pih+"</option>";
				 })
				 $("[name=t_yl_ylph_id]").html(html2);
				 html2="";

	        }
		});
	}
	////修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
			type:'get',
	   		dataType:"json",
	   		asyn:false,
	   		beforeSend:function(){
	   			 console.log("开始发送");
	   		},
	   		data:{djh:getYuangongId},
			url:uRl+"/yuanliao/Ylchuku/one_info",
			success:function(data){
				console.log(data);
				var one_info=data.result.info;
					var gys=data.result.gys//所有供应商集合
					aa(gys,one_info.t_yl_gys_id);
					$("#t_yl_gys_id").html(html1);
					html1="<option value='0'>请选择</option>";
					var cp=data.result.ck//仓库
					aa(cp,one_info.t_yl_ck_id);
					$("#t_yl_ck_id").html(html1);
					html1="<option value='0'>请选择</option>";
				    $("#rq").val(one_info.rq);
				    $("#rk_ck").val(one_info.rk_ck);
			},
			complete:function(){
				console.log("接收成功");
			}
		})
	}

})//end
