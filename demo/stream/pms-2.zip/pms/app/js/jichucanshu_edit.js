$(function(){
	var html1="";
    var str="";
 function aa(datal,info){
	for(var i=0;i<datal.length;i++){
		 	var id=datal[i].id;
		 	var mc=datal[i].name;
		 	var jibie=datal[i].jb;
		 	if(info!=0){
		 		if(info==id){
		 			html1 +='<option value="'+id+'" selected>'+mc+'</option>';
		 		}else{
		 			html1 +='<option value="'+id+'">'+mc+'</option>';
		 		}
		 	}else{
		 		html1 +='<option value="'+id+'">'+mc+'</option>';
		 	}
			if(datal[i].children!=null){
				aa(datal[i].children,info);
			}
		 }
		 
	 }
 function aa1(datal,info){
	for(var i=0;i<datal.length;i++){
	 	var id=datal[i].id;
	 	var mc=datal[i].name;
	 	if(info!=0){
	 		if(info.t_yg_bm_id==id){
	 			return mc;
	 		}else{
	 			if(datal[i].children!=null){
			        aa(datal[i].children,info);
		         }
	 		}
	 	}
		
	}
}
 ///////////////////////////
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		ajaxurl = "/renyuan/sgqy/add";
		sele();
		$("#showModal1 #myModalLabel").text("新增施工区域信息");
	} else {
		ajaxurl = "/renyuan/sgqy/one_info";
		zhuijia();
		$("#showModal1 #myModalLabel").text("修改施工区域信息");
	}
	
	////////////添加获取数据
	function sele(r){
		$.ajax({
			type:"get",
			dataType:"json",
			url:uRl+"/renyuan/sgqy/add",
			 success:function(data){
	            $("body").mLoading('hide');
//			 	console.log(data)
	          	var userlist=data.result.userlist;
	            var str33="";
	            html1="";
	            $.each(userlist,function(i,v){
	            	str33+="<option value='"+v.id+"'>"+v.xm+"</option>"
	            })
	            $("[name=t_yg_ry_id]").html(str33);//部们列表
	            str33="";
	        }
		});
	}
	////修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
			type:'get',
	   		dataType:"json",
	   		asyn:false,
	   		beforeSend:function(){
	   			 console.log("开始发送");
	   		},
	   		data:{id:getYuangongId},
			url:uRl+"/renyuan/sgqy/one_info",
			success:function(data){
//				console.log(data);
				if(data.status==1){
				var bumen=data.result.bumen;
				resstr=data.result.info;
                 var mc=aa1(bumen,resstr)
                 if(mc==""||mc==null){
                 	mc="一级部门";
                 	resstr.ssid=0;
                 }
                $("#cbad").val(mc);
                $("[name=t_yg_bm_id]").val(resstr.t_yg_bm_id);
	          	var userlist=data.result.userlist;
	            var str33="";
	            $.each(userlist,function(i,v){
	            	if(data.result.info.t_yg_ry_id==v.id){
	            		str33+="<option value='"+v.id+"' selected>"+v.xm+"</option>"
	            	}else{
	            		str33+="<option value='"+v.id+"'>"+v.xm+"</option>"
	            	}
	            })
	            $("[name=t_yg_ry_id]").html(str33);//部们列表
	             str33="";
	             $("[name=lng]").val(data.result.info.lng);
	             $("[name=lat]").val(data.result.info.lat);
	             $("[name=mc]").val(data.result.info.mc);
	             $("[name=wz]").val(data.result.info.wz);
        		$("body").mLoading('hide');
	          }
			},complete:function(){
				console.log("接收成功");
			}
		})
	}

//点击选择地图选择经纬度
$("#zb").click(function() {
	$("#zbModal").find(".modal-body").load('app/views/zb.html?time='+new Date().getSeconds());
	$("#zbModal").modal('show');
});


})//end
