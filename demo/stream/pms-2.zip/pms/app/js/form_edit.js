$(function(){
	var href=location.href;
	var href_id=href.split("?")[1];
	href_id=href_id.split("=")[1];
	$("input[type='hidden']").val(href_id.charCodeAt(href_id));
})
$("button[type='submit']").click(function(){
	alert($('#edit').serialize())
	 $.ajax({
	 		type:'post',
	 		dataType:"json",
            data:$('#edit').serialize(),
            url: uRl+"/waichu/edit",
            success:function(data,textStatus,jqXHR){
                console.log(data);
            }
        })
});
