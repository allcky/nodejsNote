$(function() {
	//日历插件
	$('.form_date').datetimepicker({
		language: 'zh-CN',
		pickerPosition: "bottom-left",
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format: 'yyyy-mm-dd'
	});
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	//	------------------------
	if(getYuangongId == '' || getYuangongId == null) { //如果存在修改id 则执行修改函数追加书数据
		$("body").mLoading('hide');
		$("#myModalLabel").text("添加施工部位信息");
	} else {
		sele();
		$("#myModalLabel").text("修改施工部位信息");
	}
	var html1 = "";
	var str = "";
	function sele(r) {
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + "/bmnews/bmnew/one_info?id="+getYuangongId,
			success: function(data) {
				console.log(data)
				var info=data.result.info;
				$("[name=title]").val(info.title);
				$("[name=js]").val(info.title);
				$("[name=js]").val(info.js);
				$("[name=publish_time]").val(info.publish_time);
				if (info.is_top==1) {
					$("[name=is_top]")[0].checked="checked";
				}else if (info.is_top==0) {
					$("[name=is_top]")[1].checked="checked";
				};
				if (info.status==1) {
					$("[name=status]")[0].checked="checked";
				}else if (info.status==0) {
					$("[name=status]")[1].checked="";
				}
				$("[name=content]").val(info.content);
				$("body").mLoading('hide');
			}
		});
	}
}) //end