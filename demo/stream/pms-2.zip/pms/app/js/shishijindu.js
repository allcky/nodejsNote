//创建websocket连接
var socket = io.connect(uRl_node);
var sys_data=[];

//把信息显示出来
socket.on('notification', function (data) {
	$.each(data.articles,function(index,article){
		if(article.bw=="1"){
			$('canvas').clearCanvas();
			fun_ajax();
		}
	});
});
var fun_ajax=function(){
	$.ajax({
		url:uRl+"xiangmu/tj/oneqytj?id=1",
		success:function(data){
			console.log(data.result.onequtj);
			var yij=data.result.onequtj;
			var qd_x=75;
			var cz_x=50;
			var ds_x=60;
			var qm_x=50;
			var sql_x=180;
			var ssql_x=75;
			var zj_x=50;
			for (var i = 0; i < yij.length; i++) {
				if(yij[i].vr=="qd"){
					fun_qd(yij[i].mc,yij[i].cz,qd_x);
					for(var j=0;j<yij[i].sun.length;j++){
						if(yij[i].sun[j].vr=="ct"){
							fun_ct(yij[i].sun[j].czjidu,cz_x);
							cz_x=cz_x+205;
						}else if(yij[i].sun[j].vr=="ds"){
							fun_ds(yij[i].sun[j].czjidu,ds_x);
							ds_x=ds_x+205;
						}
						else if(yij[i].sun[j].vr=="zj"){
							fun_zj(yij[i].sun[j].czjidu,zj_x);
							zj_x=zj_x+205;
						}
					}
					qd_x=qd_x+205;
				}else if(yij[i].vr=="sql"){
					fun_sql(yij[i].mc,yij[i].cz,sql_x);
					for(var j=0;j<yij[i].sun.length;j++){
						if(yij[i].sun[j].vr=="ssql"){
							fun_ssql(yij[i].sun[j].czjidu,ssql_x);
							ssql_x=ssql_x+205;
						}
					}
					sql_x=sql_x+205;
				}else if(yij[i].vr=="lj"){
					
				}else if(yij[i].vr=="sd"){
					
				}
			}
		}
	});
}

var fun_qd=function(mc,cz,qd_x){
	$('#myCanvas').drawText({
	  text: mc+"产值（"+cz+"）",
	  fontSize: 12,
	  x: qd_x, y: 240,
	  strokeStyle: '#656565',
	  strokeWidth: 0.5
	});
}
var fun_sql=function(mc,cz,sql_x){
	$('#myCanvas').drawText({
	  text: mc+"产值（"+cz+"）",
	  fontSize: 12,
	  x: sql_x, y: 100,
	  strokeStyle: '#656565',
	  strokeWidth: 0.5
	});
}

var fun_ct=function(czjidu,cz_x){
	$('#myCanvas').drawRect({
	      fillStyle: fun_fillStyleStr(czjidu),
  		  strokeStyle: '#000',
	      strokeWidth: 1,
	      x: cz_x, y: 200,
	      fromCenter: false,
	      width: 50,
	      height: 20
	});
}

var fun_ds=function(czjidu,ds_x){
	$('#myCanvas').drawRect({
		fillStyle: fun_fillStyleStr(czjidu),
	  	  strokeStyle: '#000',
	      strokeWidth: 1,
	      x: ds_x, y: 130,
	      fromCenter: false,
	      width: 30,
	     height: 70
	});
}

var fun_zj=function(czjidu,zj_x){
	//桩基
	$('#myCanvas').drawRect({
	    fillStyle: fun_fillStyleStr(czjidu),
		strokeStyle: '#000',
	    strokeWidth: 1,
	    x: zj_x, y: 280,
	    fromCenter: false,
	    width: 8,
	    height: 120
	});
	//桩基
//	$('#myCanvas').drawRect({
//	      fillStyle: fun_fillStyleStr(czjidu),
//	  	strokeStyle: '#000',
//	      strokeWidth: 1,
//	      x: zj_x, y: 330,
//	      fromCenter: false,
//	      width: 8,
//	     height: 120
//	});
//	//桩基
//	$('#myCanvas').drawRect({
//	      fillStyle: fun_fillStyleStr(czjidu),
//	  		strokeStyle: '#000',
//	      strokeWidth: 1,
//	      x: zj_x, y: 330,
//	      fromCenter: false,
//	      width: 8,
//	     height: 120
//	});
}

var fun_qm=function(czjidu,qm_x){
	$('#myCanvas').drawRect({
	      fillStyle: fun_fillStyleStr(czjidu),
	  		strokeStyle: '#000',
	      strokeWidth: 1,
	      x: qm_x, y: 130,
	      fromCenter: false,
	      width: 50,
	     height: 20
	});
}
var fun_ssql=function(czjidu,ssql_x){
	$('#myCanvas').drawRect({
	    fillStyle: fun_fillStyleStr(czjidu),
	  	strokeStyle: '#000',
	    strokeWidth: 1,
	    x: ssql_x, y: 110,
	    fromCenter: false,
	    width: 200,
	    height: 20
	});
}
var fun_fillStyleStr=function(czjidu){
	if(czjidu==0){
		return "#ffffff";
	}else{
		var czjidu=czjidu.replace(/%/, "");
		if(czjidu==100){
			return "#ff0000";
		}else{
			return "#ff0000";
		}
	}
}
fun_ajax();