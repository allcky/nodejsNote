var tableUrl=uRl + "/renyuan/yuangong/index?lx=1";
	var id_name;
	var obj={
		csrq:"出生日期不能为空",
		cjgzrq:"参加工作日期不能为空",
		prsj:"聘任时间不能为空",
		gw_t_sys_mb_id:"请选择岗位",
		zw_t_sys_mb_id:"请选择职务",
		t_yg_bm_id:"请选择部门"
	};
	var hd=$(window).height()-350;
	var table=$('#tableInfo').DataTable({
		"columns": [
			{
                 "sClass": "text-center",
                 "data": "id",
                 "render": function (data, type, full, meta) {
                     return '<input type="checkbox"  class="checkchild"  value="' + data + '" />';
                 },
                 "bSortable": false
            },
			{
                 "sClass": "text-center",
                 "data": "tx",
                 "render": function (data, type, full, meta) {
                 	if (data==""||data==null) {
                    	return '<img width="20" height="20" src="app/img/logo-icon.png"/>';
                 	}else{
                 		var arrdata=data.split(",");
                 		return '<img width="20" height="20" src='+uploadUrl+arrdata[0]+'>';
                 	};
                 },
                 "bSortable": false
            },
			{ "data": "xm" },
			{ "data": "xb" },
			{ "data": "csrq" },
			{ "data": "gw_t_sys_mb_id" },
			{ "data": "zw_t_sys_mb_id" },
			{ "data": "t_yg_bm_id" },
			{ "data": "zyjszc" },
			{ "data": "lxfs" }
		],
		"searching": false,
		"lengthChange": false,
		"pageLength":10,
		"checkAllId": "employeeCheckAll",
		"paging":true,			//是否显示分页
		"processing":true,			
		"serverSide":true ,     //启动覆盖页分页
		"autoWidth" : true, 	//是否自适应宽度 
		"scrollCollapse": false,
		"ajax":{
			"url":tableUrl,
			"error":function(jqXHR,textStatus,errorMsg){
				notify("数据加载失败!", "danger");
			}
		}, 
		
		"language": {
               "sProcessing": "数据加载中...",
               "sLengthMenu": "显示 _MENU_ 条结果",
               "sInfo": "显示第 _START_ 至 _END_ 项  作业人员信息，共 _TOTAL_ 条",
               "sInfoEmpty": "显示第 0 至 0 条员工信息，共 0 条",
               "sLoadingRecords": "载入中...",
               "sInfoThousands": ","
      },
      "createdRow": function ( row, data, index ) {
			$('td', row).eq(0).css('text-align',"center");
			$('td', row).eq(1).css('text-align',"center");
			$('td', row).eq(2).css('text-align',"center");
			$('td', row).eq(3).css('text-align',"center");
			$('td', row).eq(4).css('text-align',"center");
			$('td', row).eq(5).css('text-align',"center");
			$('td', row).eq(6).css('text-align',"center");
			$('td', row).eq(7).css('text-align',"center");
			$('td', row).eq(8).css('text-align',"left");
			$('td', row).eq(9).css('text-align',"center");
        },
	});
	////
	
	////
	$('#tableInfo tbody').on('click', 'tr', function() {
		var table = $('#tableInfo').DataTable();
		if($(this).hasClass('selected')) {
			$(this).removeClass('selected');
			$(this).find("td input")[0].checked="";
		} else {
			table.$('tr.selected').removeClass('selected');
			$(this).addClass('selected');
			$(".checkchild").each(function(s){
				$(".checkchild")[s].checked=""
			});
			$(this).find("td input")[0].checked="checked";
			$("[name=editInfo]").attr("disabled",false);
			$("[name=delInfo]").attr("disabled",false);
		};
		var name = $('td', this).eq(0)[0].innerHTML;
		id_name=(name.replace('<input type="checkbox" class="checkchild" value="','')).replace('">','');
	});
	$("[name=delInfo]").click(function() {
		if($('#tableInfo tbody>tr').hasClass('selected')) {
			Common.confirm({message:"确认删除员工信息吗？",operate:function(reselt){if(reselt){
				$.ajax({
					type: "post",
					url: uRl + "/renyuan/yuangong/delete",
					data: { id: id_name },
					success: function(data) {
						if(data.status == 1) {
							notify(data.result, "success");
							$('#tableInfo').DataTable().row('.selected').remove().draw( false );
						}else{
							notify(data.result, "danger");
						}
					}
				});
			}}});
				
		}else{
			notify("请至少选择一条员工信息", "danger");
		};
	});
	$("[name=addInfo]").click(function() {
		var num=0;
		id_name="";
		createLoading("zyrygl_edit","#showModal1","#showModal2","jz");
	});
	$("[name=editInfo]").click(function() { 
		if($('#tableInfo tbody>tr').hasClass('selected')) {
			createLoading("zyrygl_edit","#showModal1","#showModal2","jz");
		}else{
			notify("请至少选择一条员工信息", "danger");
		}
	});
	$("[name=save_button1]").click(function(){
		if(id_name==""){
			addedit("add",obj);
		}else{
			addedit("edit?id="+id_name,obj);
		}
	});
	$("[name=checkAll]").click(function(){
		var check = $(this).prop("checked");
      	$(".checkchild").prop("checked",check);
      	$("#del").attr("disabled",false);
	});
	$("#tableInfo").on("click",".checkchild",function(){
		if (!$(this)[0].checked) {
			$(this).siblings("input").prop("checked",false);
			$("[name=checkAll]").prop("checked",false);
		}
	});
	//刷新数据源
	$('#reload').click(function() {
		table.ajax.url(tableUrl).load();
	});
	
	
	//添加/编辑
	function addedit(r,odj){
		if ($("#xm").val()==""||$("#xm").val()==null) {
			notify("姓名不能为空!","danger");
			return false;
		}
		if(odj){
			for(n in odj){
				if ($("[name="+n+"]").val()==""||$("[name="+n+"]").val()==null ||$("[name="+n+"]").val()==0) {
					notify(odj[n],"danger");
					return false;
				}
			}
		}
		$.ajax({
			url: uRl+"/renyuan/yuangong/"+r,
	 		type:'post',
	 		dataType:"json",
	 		asyn:false,
	 		timeout:2000,
		    data:$('#tj').serialize(),
		    beforeSend:function(XMLHttpRequest){
	            console.log('发送前');
	        },
		    success:function(data,teyuangong_submit3xtStatus,jqXHR){
		       if(data.status==1){
		       	$('#tableInfo').DataTable({
				    ajax: tableUrl
				}).ajax.reload(null, false);
		       	$('#showModal1').modal('hide');
		       	console.log("发送成功");
		       }
		       if(data.status==0){
		       	console.log("发送失败");
		       }
		    }
	    })
	}
	//检索功能
	var this_name;
	$("#setting>li").click(function(){
		var html=$(this).find("a").text();
		var cla=$(this).find("a>i").attr("class");
		$("#content_qwjs").html(html);
		$("#content_qwjs11").attr("class",cla);
		this_name=$(this).find("a")[0].name;
	});
	//获取搜索框里面的内容
	$('#search').click(function(){
		if (this_name==undefined||this_name=="") {
			notify("请选择类型!","danger");
		}else{
			if ($("#search_content").val()==""||$("#search_content").val()==null) {
				notify("请输入内容","danger");
				return false;
			}else{
				var getValue=$("#search_content").val();
				tableUrl=uRl + "/renyuan/yuangong/index?lx=1&"+this_name+"="+getValue;
				table.ajax.url(tableUrl).load();
				this_name="";
			};
		}
	});