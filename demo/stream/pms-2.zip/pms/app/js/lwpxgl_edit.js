	//日历插件
	$('.form_date').datetimepicker({
		language: 'zh-CN',
		pickerPosition: "bottom-left",
		weekStart: 1,
		todayBtn: 1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format: 'yyyy/mm/dd'
	});
	if(thisName == "add") {
		$("#showModal1 #myModalLabel").html("新增培训计划");
		$("body").mLoading('hide');
	} else if(thisName == "edit") {
		// 修改
		if($("[name='jihua']:checkbox:checked").length != 1) {
			notify("请选择至少一条信息", "danger");
		}
		// 数据标示
		var id = $("[name='jihua']:checkbox:checked")[0].value;
		var modal = $(this);
		// 从服务器获取数据
		$.ajax({
			type: "post",
			url: uRl + "/renyuan/peixun/one_info",
			async: true,
			data: {
				id: id
			},
			success: function(data) {
				console.log(data)
				var info = data.result.info;
				$("#showModal1 #myModalLabel").html("修改培训计划");
				$("[name='mc']").val(info.mc);
				$("[name='fzr']").val(info.fzr);
				$("[name='skr']").val(info.skr);
				$("[name='zf']").val(info.zf);
				$("[name='hgx']").val(info.hgx);
				$("[name='bz']").val(info.bz);
				$("[name='statetime']").val(info.statetime);
				$("[name='addtime']").val(info.addtime);
				$("body").mLoading('hide');
			}
		});
	}