$(function(){
	var getYuangongId=localStorage.getItem("edit_id");
	$("input[name='id']").val(getYuangongId);
	var html1="";
    var str="";
 function aa(datal,info){
	for(var i=0;i<datal.length;i++){
		 	var id=datal[i].id;
		 	var mc=datal[i].name;
		 	var jibie=datal[i].jb;
		 	switch (jibie){
		 		case 1:
			 		str="";
			 			break;
		 		case 2:
			 		str="|——";
			 			break;
		 		case 3:
			 		str="|————";
			 			break;
		 		default:
		 			str="|————————";
			 			break;
		 	}
		 	if(info!=0){
		 		if(info.id==id){
		 			html1 +='<option value="'+id+'" selected>'+str+mc+'</option>';
		 		}else{
		 			html1 +='<option value="'+id+'">'+str+mc+'</option>';
		 		}
		 	}else{
		 		html1 +='<option value="'+id+'">'+str+mc+'</option>';
		 	}
			if(datal[i].children!=null){
				aa(datal[i].children,info);
			}
		 }
		 
	 }
     			 
	function sele(r){
		$.ajax({
			type:"get",
			dataType:"json",
			url:uRl+"/xiangmu/sgbwhb/add",
			 success:function(data){
			 	console.log(data);
	          	var bm=data.result.bumen;//部门列表
	          	var sgbw=data.result.sgbw;//施工部位
	          	var str44='';
	            aa(bm,0);
	            $("[name=t_yg_bm_id]").html(html1);//部门列表
	            html1="";
	            $.each(sgbw,function(i,v){
	            	str44+="<option value='"+v.id+"'>"+v.mc+"</option>"
	            })
	            $("[name=t_xm_sgbw_id]").html(str44);//施工部位
	            str44="";
	            $("body").mLoading('hide');
	        }
		});
	}
//	------------------------
	if(getYuangongId==''||getYuangongId==null){  //如果存在修改id 则执行修改函数追加书数据
		sele('1')
		$("#mb_xx").text("员工信息录入");
	}else{
		sele('0');
		$("#mb_xx").text("员工信息修改");
	}
////	-------------------点击提交-------------------------------
})//end
