$.ajaxSetup({
	"type":"post",
	dataType:"json",
	asnc:false,
	error:function(msg){
		alert(msg);
	}
});
$.ajax({
	url:uRl+"/waichu/index",
	success:function(data){
		var data_len=data.result.list.length;
		var old='<tr style="font-weight: bold"><td><input type="checkbox"></td><td>单据编号</td><td>申请日期</td><td>申请人</td><td>申请部门</td><td>外出事由</td><td>外出时间</td><td>返回时间</td><td>外出时长</td><td>随行人员</td><td>外出结果</td> <td>操作</td></tr>';
		$("#table tbody").html(old);
		var id_arr=[];
		for (var i = 0; i < data_len; i++) {
			var id=String.fromCharCode(data.result.list[i].id);
 			var html='<tr>'+'<td><input type="checkbox"></td><td>'+data.result.list[i].bianhao+'</td><td>'+data.result.list[i].addtime+'</td><td>'+data.result.list[i].name+'</td><td>部门一</td><td>'+data.result.list[i].bumenid+'</td><td>'+data.result.list[i].wcsy+'</td><td>'+data.result.list[i].wcsj+'</td><td>'+data.result.list[i].wctime+'</td><td>'+data.result.list[i].fhtime+'</td><td>'+data.result.list[i].sxren+'</td><td style="white-space: nowrap"><div class="buttons"><a style="color:white;" href="#/app/form-edit?id='+id+'"><button ng-click="table.saveUser($index)" title="Edit" class="btn btn-sm btn-info edit"style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-pencil"></em></button></a><button name='+data.result.list[i].id+' '+'title="Delete" class="btn btn-sm btn-danger removeBtn" style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-trash"></em></button></div></td></tr>'
			$(html).appendTo($("#table"));
			id_arr.push(data.result.list[i].id);
			localStorage.setItem("id",id_arr);
		}
	}
});
//首页
$("#first").click(function(){
	$.ajax({
	url:uRl+"/waichu/index",
	success:function(data){
		var data_len=data.result.list.length;
		var old='<tr style="font-weight: bold"><td><input type="checkbox"></td><td>单据编号</td><td>申请日期</td><td>申请人</td><td>申请部门</td><td>外出事由</td><td>外出时间</td><td>返回时间</td><td>外出时长</td><td>随行人员</td><td>外出结果</td> <td>操作</td></tr>';
		$("#table tbody").html(old);
		for (var i = 0; i < data_len; i++) {
 			var html='<tr><td><input type="checkbox"></td><td>'+data.result.list[i].bianhao+'</td><td>'+data.result.list[i].addtime+'</td><td>'+data.result.list[i].name+'</td><td>部门一</td><td>'+data.result.list[i].bumenid+'</td><td></td><td></td><td></td><td></td><td></td><td style="white-space: nowrap"><div class="buttons"><a style="color:white;" href="#/app/form-edit"><button ng-click="table.saveUser($index)" title="Edit" class="btn btn-sm btn-info edit"style="margin-bottom: 1px;font-size: 12px"> <em class="fa fa-pencil"></em></button></a><button name='+data.result.list[i].id+' '+'title="Delete" class="btn btn-sm btn-danger removeBtn" style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-trash"></em></button></div></td></tr>'
			$(html).appendTo($("#table"));
		}
	}
});
});
//第一页
var num=1;
$(".table_one").each(function(index){
	$(this).click(function(index){
		var index=$(this).index();
		num=index+1;
		$.ajax({
			url:uRl+"/waichu/index",
			data:{page:index},
			success:function(data){
				var data_len=data.result.list.length;
				var old='<tr style="font-weight: bold"><td><input type="checkbox"></td><td>单据编号</td><td>申请日期</td><td>申请人</td><td>申请部门</td><td>外出事由</td><td>外出时间</td><td>返回时间</td><td>外出时长</td><td>随行人员</td><td>外出结果</td> <td>操作</td></tr>';
				$("#table").html(old);
				for (var i = 0; i < data_len; i++) {
		 			var id=String.fromCharCode(data.result.list[i].id);
 					var html='<tr>'+'<td><input type="checkbox"></td><td>'+data.result.list[i].bianhao+'</td><td>'+data.result.list[i].addtime+'</td><td>'+data.result.list[i].name+'</td><td>部门一</td><td>'+data.result.list[i].bumenid+'</td><td></td><td></td><td></td><td></td><td></td><td style="white-space: nowrap"><div class="buttons"><a style="color:white;" href="#/app/form-edit?id='+id+'"><button ng-click="table.saveUser($index)" title="Edit" class="btn btn-sm btn-info edit"style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-pencil"></em></button></a><button name='+data.result.list[i].id+' '+'title="Delete" class="btn btn-sm btn-danger removeBtn" style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-trash"></em></button></div></td></tr>'
					$(html).appendTo($("#table"));
				}
			}
		});
		return num;
	});
});
$("#DataTables_Table_2_next").click(function(){
	if(num<=3){
		num++;
	};
	$.ajax({
			url:uRl+"/waichu/index",
			data:{page:num},
			success:function(data){
				console.log(data);
				var data_len=data.result.list.length;
				var old='<tr style="font-weight: bold"><td><input type="checkbox"></td><td>单据编号</td><td>申请日期</td><td>申请人</td><td>申请部门</td><td>外出事由</td><td>外出时间</td><td>返回时间</td><td>外出时长</td><td>随行人员</td><td>外出结果</td> <td>操作</td></tr>';
				$("#table").html(old);
				for (var i = 0; i < data_len; i++) {
		 			var html='<tr><td><input type="checkbox"></td><td>'+data.result.list[i].id+'</td><td>'+data.result.list[i].addtime+'</td><td>'+data.result.list[i].name+'</td><td>部门一</td><td>'+data.result.list[i].bumenid+'</td><td></td><td></td><td></td><td></td><td></td><td style="white-space: nowrap"><div class="buttons"><button ng-click="table.saveUser($index)" title="Edit" class="btn btn-sm btn-info edit"style="margin-bottom: 1px;font-size: 12px"> <em class="fa fa-pencil"></em></button><button name='+data.result.list[i].id+' '+'title="Delete" class="btn btn-sm btn-danger removeBtn" style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-trash"></em></button></div></td></tr>'
					$(html).appendTo($("#table"));
				}
			}
		});
});
$("#DataTables_Table_2_previous").click(function(){
	if(num>=1){
		num--;
	};
	$.ajax({
			url:uRl+"/waichu/index",
			data:{page:num},
			success:function(data){
				var data_len=data.result.list.length;
				var old='<tr style="font-weight: bold"><td><input type="checkbox"></td><td>单据编号</td><td>申请日期</td><td>申请人</td><td>申请部门</td><td>外出事由</td><td>外出时间</td><td>返回时间</td><td>外出时长</td><td>随行人员</td><td>外出结果</td> <td>操作</td></tr>';
				$("#table").html(old);
				for (var i = 0; i < data_len; i++) {
		 			var html='<tr><td><input type="checkbox"></td><td>'+data.result.list[i].id+'</td><td>'+data.result.list[i].addtime+'</td><td>'+data.result.list[i].name+'</td><td>部门一</td><td>'+data.result.list[i].bumenid+'</td><td></td><td></td><td></td><td></td><td></td><td style="white-space: nowrap"><div class="buttons"><button ng-click="table.saveUser($index)" title="Edit" class="btn btn-sm btn-info edit"style="margin-bottom: 1px;font-size: 12px"> <em class="fa fa-pencil"></em></button><button name='+data.result.list[i].id+' '+'title="Delete" class="btn btn-sm btn-danger removeBtn" style="margin-bottom: 1px;font-size: 12px"><em class="fa fa-trash"></em></button></div></td></tr>'
					$(html).appendTo($("#table"));
				}
			}
		});
});
//删除ajax行数据
$("#table tbody").on("click","tr .removeBtn",function(){
	var parent=$(this).parent().parent().parent();
	var getName=this.name;
	if(window.confirm("您确定要删除吗?")){
		$.ajax({
			url:uRl+"/waichu/delete",
			data:{id:getName},
			success:function(data){
				if(data.status==1){
					console.log(this);
					parent.remove();
//					console.log("删除成功");
				}
	//			var getId=localStorage.getItem("id");
			}
		});
	}
});
//编辑ajax行数据
$("#table tbody").on("click","tr .edit",function(){
	var getId=$(this).parent().find(".removeBtn").attr("name");
	$.ajax({
		url:uRl+"/waichu/one_info",
		success:function(data,status,xhr){
			if(data.status==0) alert("参数错误");
		}
	});
});
//添加信息
$(".add").click(function(){
	
});
