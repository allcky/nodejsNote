$(function(){
	var html1="";
    var str="";
 function aa(datal,info){
	for(var i=0;i<datal.length;i++){
		 	var id=datal[i].id;
		 	var mc=datal[i].mc;
		 	var jibie=datal[i].jb;
		 	switch (jibie){
		 		case 1:
			 		str="";
			 			break;
		 		case 2:
			 		str="|——";
			 			break;
		 		case 3:
			 		str="|————";
			 			break;
		 		default:
		 			str="|————————";
			 			break;
		 	}
		 	if(info!=0){
		 		if(info.id==id){
		 			html1 +='<option value="'+id+'" selected>'+str+mc+'</option>';
		 		}else{
		 			html1 +='<option value="'+id+'">'+str+mc+'</option>';
		 		}
		 	}else{
		 		html1 +='<option value="'+id+'">'+str+mc+'</option>';
		 	}
			if(datal[i].children!=null){
				aa(datal[i].children,info);
			}
		 }
		 
	 }
 
 ///////////////////////////
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		ajaxurl = "/yuanliao/ylph/add";
		sele();
	} else {
		ajaxurl = "/yuanliao/ylph/one_info";
		one_info();
	}
	
	////////////添加获取数据
	function sele() {
	
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + ajaxurl,
			success:function(data){
			 	console.log(data)
	          	var yllx=data.result.yllx;
	          	var gys=data.result.gys;
	            aa(yllx,0);
	            $("[name=gg_t_yl_yllx_id]").html(html1);
	           html1=""
	            var str22="";
	            $.each(gys,function(i,v){
	            	str22+="<option value='"+v.id+"'>"+v.mc+"</option>"
	            })
	            $("[name=gys_t_yl_gys_id]").html(str22);
	            str22="";
	        }
		});
	}
	
	
	//修改追加数据  zhuijia();
	function one_info() {
		$.ajax({
			type: 'get',
			dataType: "json",
			asyn: false,
			beforeSend: function() {
//				console.log("开始发送");
			},
			data: { id: getYuangongId},
			url: uRl + ajaxurl,
			success:function(data){
				console.log(data);
				if(data.status==1){
					$("[name=pih]").val(data.result.info.pih);
					$("[name=paih]").val(data.result.info.paih);
					aa(data.result.yllx,data.result.info.gg_t_yl_yllx_id);
					$("[name=gg_t_yl_yllx_id]").html(html1);
	                html1=""
					var str22="";
					var gys=data.result.gys
	                $.each(gys,function(i,v){
	               	if(data.result.info.gys_t_yl_gys_id==v.id){
	               		str22+="<option value='"+v.id+"' selected>"+v.mc+"</option>"
	               	}else{
	               		str22+="<option value='"+v.id+"'>"+v.mc+"</option>"
	               	}
	            
	               })
	               $("[name=gys_t_yl_gys_id]").html(str22);
	               str22="";
	          };
			},complete:function(){
				console.log("接收成功");
			}
		})
	}

})//end
