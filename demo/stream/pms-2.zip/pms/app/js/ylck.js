var tableUrl = uRl + "/yuanliao/Ylchuku/index?lx=1";
var id_name;
var boo = false;
var hd = $(window).height() - 350;
$('#tableInfo').DataTable({
	"searching": false,
	"lengthChange": false,
	"pageLength": 10,
	"checkAllId": "employeeCheckAll",
	"paging": true, //是否显示分页
	"processing": true,
	"serverSide": true, //启动覆盖页分页
	"autoWidth": true, //是否自适应宽度 
	"scrollCollapse": false,
	"scrollY": hd + "px",
	"ajax": {
		"url": tableUrl,
		"error": function(jqXHR, textStatus, errorMsg) {
			notify("数据加载失败!", "inverse");
		}
	},
	"columns": [{
			"sClass": "text-center",
			"data": "id",
			"render": function(data, type, full, meta) {
				return '<input type="checkbox"  class="checkchild"  value="' + data + '" />';
			},
			"bSortable": false
		},
		{ "data": "djh" },
		{ "data": "rq" },
		{ "data": "mxh" },
		{ "data": "t_xm_sgbw_id" },
		{ "data": "ckren" },
		{ "data": "zt" },
		{ "data": "userid" },
	],
	"language": {
		"sProcessing": "数据加载中...",
		"sLengthMenu": "显示 _MENU_ 条结果",
		"sInfo": "显示第 _START_ 至 _END_ 项员工信息，共 _TOTAL_ 条",
		"sInfoEmpty": "显示第 0 至 0 条员工信息，共 0 条",
		"sLoadingRecords": "载入中...",
		"sInfoThousands": ","
	},
});
$.fn.dataTable.ext.errMode = 'none';
$('#tableInfo tbody').on('click', 'tr', function() {
	var table = $('#tableInfo').DataTable();
	if($(this).hasClass('selected')) {
		$(this).removeClass('selected');
		$(this).find("td input")[0].checked = "";
	} else {
		table.$('tr.selected').removeClass('selected');
		$(this).addClass('selected');
		$(".checkchild").each(function(s) {
			$(".checkchild")[s].checked = ""
		});
		$(this).find("td input")[0].checked = "checked";
		$("[name=editInfo]").attr("disabled", false);
		$("[name=delInfo]").attr("disabled", false);
	};
	var name = $('td', this).eq(0)[0].innerHTML;
	id_name = (name.replace('<input type="checkbox" class="checkchild" value="', '')).replace('">', '');
});
$("[name=delInfo]").click(function() {
	if($('#tableInfo tbody>tr').hasClass('selected')) {
		$.ajax({
			type: "get",
			url: uRl + "/yuanliao/ylph/delete",
			data: { id: id_name },
			success: function(data) {
				if(data.status == 1) {
					notify(data.result, "inverse");
					$('#tableInfo').DataTable().row('.selected').remove().draw(false);
				} else {
					notify(data.result, "inverse");
				}
			}
		});
	} else {
		notify("请选择至少一条", "inverse");
	};
});
$("[name=addInfo]").click(function() {
	id_name = ""
	location.href = "#/app/ylck2";
})
$("[name=editInfo]").click(function() {
	if($('#tableInfo tbody>tr').hasClass('selected')) {
		var arr = [];
		arr.push(id_name);
		localStorage.setItem("id", arr);
		location.href = "#/app/ylck2";
	} else {
		notify(data.result, "inverse");
	}
});
$("[name=checkAll]").click(function() {
	var check = $(this).prop("checked");
	$(".checkchild").prop("checked", check);
	$("#del").attr("disabled", false);
});