//左侧菜单开始接口

//初始化
(function init(){
	$(".sideBar .sideBar_content .sub_sideBar_content").hide();
	$(".sideBar .sideBar_content .sub_sideBar_content ol").hide();
})();
//点击显示事件
//监听事件

//二级菜单
$(".sideBar .sideBar_content>a").each(function(n){
	var flag=true;
	$(this).click(function(){
        $(this).css("color","#fff");
        $(".sideBar .sideBar_content ul li ").children().css("color","#fff");
		$(".sideBar .sideBar_content .sub_sideBar_content").not(":eq("+n+")").slideUp(300);
		$(".sideBar .sideBar_content .sub_sideBar_content ol").not(":eq("+n+")").slideUp();
		$(".sideBar .sideBar_content .sub_sideBar_content").eq(n).slideToggle(300);
		$(".sideBar .sideBar_content>a").not(":eq("+n+")").css("color","#515253");
		$(".sideBar .sideBar_content").not(":eq("+n+")").css("background","");
		if(flag){
            $(".sideBar .sideBar_content>a>i").removeClass("indented tree-icon icon-plus  glyphicon glyphicon-plus fa fa-plus").addClass("indented tree-icon glyphicon fa icon-minus glyphicon-minus fa-minus");
            $(".sideBar .sideBar_content").eq(n).css({"background":"#1998e5","borderRadius":"5px"});
            flag=false;
		}else {
            $(".sideBar .sideBar_content>a>i").removeClass("indented tree-icon glyphicon fa icon-minus glyphicon-minus fa-minus").addClass("indented tree-icon icon-plus  glyphicon glyphicon-plus fa fa-plus");
            $(".sideBar .sideBar_content").eq(n).css({"background":"transparent","borderRadius":"5px"});
            $(this).css("color","#19CDE5");


            flag=true;
		}
	});
});
