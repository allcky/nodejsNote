$(function(){
	var i=0;
	function loadScript(url) {
    	var script = document.createElement("script");
    	script.type = "text/javascript";
    	script.src = url;
    	document.body.appendChild(script);
	}
	// 动态加载css文件
    function loadStyles(url) {
        var link = document.createElement("link");
        link.type = "text/css";
        link.rel = "stylesheet";
        link.href = url;
        document.getElementsByTagName("head")[0].appendChild(link);
    }
 	function loadResource(){
	  loadScript("vendor/jquery-treetable/js/jquery.treetable.js");
	  loadScript("vendor/jquery-treetable/js/jquery-ui.js");
	}
 	var fn_ajax_bm=function(){
	 	$.ajax({
        	type:"get",
        	url:uRl+"/renyuan/bm/index?lx=1",
        	async:true,
        	success:function(data){
	            console.log(data);
        		 var html;
        		 datal=data.result.list;
        		 var fn_bm=function(datal){
        			 for(var i=0;i<datal.length;i++){
        			 	var id=datal[i].id;
        			 	var bz=datal[i].bz;
        			 	 if(bz==null || bz==" "){
        			 	 	bz="无";
        			 	 }
            			 html +='<tr data-tt-id='+datal[i].id+' data-tt-parent-id='+datal[i].ssid+'>'
            			 +'<td>'
            			 + datal[i].text + '</td>'
            			 +'<td>'
            			 + bz + '</td>'
            			 +'<td class="tr_center">'
		                 +     '<div class="buttons">'
		                 +         	'<a class="edit" name="edit" style="color: #43d967;">'
		                 +           	'<em class="fa fa-pencil"></em>'
		                 +         	'</a>'
		                 +     		'<a class="removeBtn" name="'+id+'"   style="color: #f05050;">'
		                 +       		'<em class="fa fa-trash"></em>'
		                 +   		'</a>'
	                 	 +		'</div>'
		                 +'</td>'
            			 +'</tr>';
            			 if(datal[i].children!=null){
            				 fn_bm(datal[i].children);
            			 }
            		 }
        		 }
        		 fn_bm(datal); 
        		 $('#treeTable1').append(html);
        		 loadResource();
        		 $("#treeTable1").treetable({  
       	            expandable : true
       	        }); 
        	}
        });
 	}
    fn_ajax_bm();
    
    //删除行
    function delTr(){
    	$("#treeTable1").on("click",".removeBtn",function(){
    			//获取id
	    	var id=this.name;
	    	var parent=$(this).parent().parent().parent();
    		//获取数据
    	
    		$.ajax({
    			type:"get",
    			url:uRl+"/renyuan/bm/delete",
    			async:true,
  			    data:{id:id},
    			success:function(data){
    				if(data.status==1){
    					parent.remove();
    					notify(data.result,"inverse");
    				};
    				if(data.status==0){
    					notify(data.err_msg,"inverse");
    				};
    			}
    		});
    	});
    }
    delTr();
    
    //添加行
    function addTr(){
    	$(".add").on("click",function(){
//    		获取id
			var getId=$(this).siblings().attr("name");
			//添加到缓存
			localStorage.setItem("id",null);
			location.href="#/app/form-validation";
    	})
    	
//  	localStorage.removeItem("id");
    };
    addTr();
    //编辑行
    function editTr(){
    	$("#treeTable1").on("click",".edit",function(){
//    		获取id
			var getId=$(this).siblings().attr("name");
			//添加到缓存
			localStorage.setItem("id",getId);
			location.href="#/app/form-validation";
    	});
//  	localStorage.removeItem("id");
    };
    editTr();
});
