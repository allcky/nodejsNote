//弹出框
$(function () {
    $("#dialog").css('display', 'none');
})
function dialog() {
    $("#dialog").css('display', 'block');
}
$("#closeThisDialog").click(function () {
    $("#dialog").css('display', 'none');
});
//全选
$(function () {
    $(".main").find("input").change(function () {
        if ($(".main label input")[0].checked) {
            $(".group input").each(function (index) {
                $(".group input")[index].checked = "checked";
            });
        } else {
            $(".group input").each(function (index) {
                $(".group input")[index].checked = "";
            })
        }
    });

    function setSelectAll() {
        var obj = $(".group input");
        var count = obj.length;
        var selectCount = 0;

        for (var i = 0; i < count; i++) {
            if (obj[i].checked) {
                selectCount++;
            }
        }

        if (count == selectCount) {
            $(".main label input").eq(0).prop("checked",true);
        } else {
            $(".main label input").eq(0).prop("checked",false);

        }
        setTimeout(setSelectAll, 10);
    }
    setSelectAll();

})
//分页
$(function(){
    //这是一个非常简单的demo实例，让列表元素分页显示
    //回调函数的作用是显示对应分页的列表项内容
    //回调函数在用户每次点击分页链接的时候执行
    //参数page_index{int整型}表示当前的索引页
    var initPagination = function() {
        var num_entries = $("#hiddenresult div.result").length;
        // 创建分页
        $("#Pagination").pagination(num_entries, {
            num_edge_entries: 3, //边缘页数
            num_display_entries: 3, //主体页数
            callback: pageselectCallback,
            items_per_page:1 //每页显示1项
        });
    }();

    function pageselectCallback(page_index, jq){
        var new_content = $("#hiddenresult div.result:eq("+page_index+")").clone();
        $("#Searchresult").empty().append(new_content); //装载对应分页的内容
        return false;
    }
});
// $("#tree_3").jstree({
//             "core" : {
//                 "themes" : {
//                     "responsive": false
//                 }, 
//                 // so that create works
//                 "check_callback" : true,
//                 'data' : function (obj, callback) {
//                     var jsonstr="[]";
//                     var jsonarray = eval('('+jsonstr+')');
//                     $.ajax({
//                         type: "POST",
//                         url:uRl+"/renyuan/bm/index",
//                         dataType:"json",
//                         async: false,
//                         success:function(msg) {
//                             alert(msg)
//                             var arrays= msg.result.list;
//                             for(var i=0 ; i<arrays.length; i++){
//                                 var arr = {
//                                         "id":arrays[i].id,
//                                         "parent":arrays[i].ssid=="0"?"#":arrays[i].ssid,
//                                         "text":arrays[i].mc
//                                 }
//                                 jsonarray.push(arr);
//                             }
//                         }

//                     });
//                     callback.call(this, jsonarray);
//                 }
//             },
//             "types" : {
//                 "default" : {
//                     "icon" : "fa fa-folder icon-state-warning icon-lg"
//                 },
//                 "file" : {
//                     "icon" : "fa fa-file icon-state-warning icon-lg"
//                 }
//             },
//             "state" : { "key" : "demo3" },
//             "plugins" : [ "dnd", "state", "types" ]
//         });

    


// $("#tree_3").jstree({
// 	"core" : {
// 		"themes" : {
// 			"responsive" : false
// 		},
// 		// so that create works
// 		"check_callback" : true,
// 		'data' : [{
// 			"text" : "根目录",
// 			"children" : [{
// 				"text" : "I",
// 				"state" : {
// 					"selected" : true
// 				}
// 			}, {
// 				"text" : "第一级"
// 			}, {
// 				"text" : "第一级",
// 				"state" : {
// 					"opened" : true
// 				},
// 				"children" : [{
// 					"text" : "第三级"
// 				}]
// 			}]
// 		}]
// 	},
// 	"types" : {
// 		"default" : {
// 			"icon" : "fa fa-file text-primary fa-lg"
// 		},
// 		"file" : {
// 			"icon" : "fa fa-file text-primary fa-lg"
// 		}
// 	},
// 	"state" : {
// 		"key" : "demo2"
// 	},
// 	"plugins" : ["types"]
// });
