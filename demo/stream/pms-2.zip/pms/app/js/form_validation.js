$(function(){
	var getYuangongId=localStorage.getItem("id");
	$("input[name='id']").val(getYuangongId);
//	------------------------
	if(getYuangongId=='' || getYuangongId=="null"){  //如果存在修改id 则执行修改函数追加书数据
		sele('1');
		addedit("add");
		$("#mb_xx").text("部门信息录入");
	}else{
		sele('0');
		zhuijia();
		addedit("edit");
		$("#mb_xx").text("部门信息修改");
	}
    var html1="<option value='0'>一级部门</option>";
    var str="";
   function aa(datal,info){
   		for(var i=0;i<datal.length;i++){
			 	var id=datal[i].id;
			 	var mc=datal[i].text;
			 	var jibie=datal[i].jb;
			 	switch (jibie){
			 		case 1:
    			 		str="";
    			 			break;
			 		case 2:
    			 		str="|——";
    			 			break;
			 		case 3:
    			 		str="|————";
    			 			break;
			 		default:
			 			str="|————————";
    			 			break;
			 	}
			 	if(info!=0){
			 		if(info.id==id){
			 			html1 +='<option value="'+id+'" selected>'+str+mc+'</option>';
			 		}else{
			 			html1 +='<option value="'+id+'">'+str+mc+'</option>';
			 		}
			 	}else{
			 		html1 +='<option value="'+id+'">'+str+mc+'</option>';
			 	}
    			if(datal[i].children!=null){
    				aa(datal[i].children,info);
    			}
    		 }
			 
		 }
           
        			 
	function sele(r){
		$.ajax({
			type:"get",
			dataType:"json",
			url:uRl+"/renyuan/bm/add?lx=1",
			 success:function(data){
	//        console.log(data);
	          var bumen=data.result.bumen;
	            aa(bumen,0);
	            $("[name=ssid]").html(html1);
	        }
		});
	}
	//修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
			type:'get',
	   		dataType:"json",
	   		asyn:false,
	   		beforeSend:function(){
	   			 console.log("开始发送");
	   		},
	   		data:{id:getYuangongId},
			url:uRl+"/renyuan/bm/one_info?lx=1",
			success:function(data){
				console.log(data)
				if(data.status==1){
				console.log(data.result.bumen)
					aa(data.result.bumen,data.result.info);
					$("[name=ssid]").html(html1);
					$("[name='mc']").val(data.result.info.mc);
					$("textarea[name='bz']").val(data.result.info.bz);
	           };
				if(data.status==0) alert("参数错误");
			},complete:function(){
				console.log("接收成功");
			}
		})
	}
//	-------------------点击提交-------------------------------

	function addedit(r){
		$("#saveYuanGongInfo").click(function(){
			if($("select[name='ssid']").val()=="0"){
				notify("所属部门不能空!", "inverse");
			}else if($("[name=mc]").val()==" "){
				notify("部门名称必须选择!", "inverse");
			}else{
				$.ajax({
					url: uRl+"/renyuan/bm/"+r,
			 		type:'post',
			 		dataType:"json",
			 		asyn:false,
				    data:$('#yuangong_submit3').serialize(),
				    success:function(data,textStatus,jqXHR){
				       	console.log(data)
				       	if(localStorage.getItem("id")){
				       		localStorage.removeItem("id")//请求成功后 清空 修改id
				       	}
				       if(data.status==1){
				       	console.log("发送成功");
				      	location.href="#/app/zydgl_edit";
				       }
				       if(data.status==0){
				       	console.log("发送失败");
				       }
				    }
			    })
			}
			 localStorage.clear();
	   })
	}
})//end
