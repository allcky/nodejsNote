$(function () {
    $('#tree').abixTreeList();
});
$(function () {
    $(".aa").each(function (i) {
        var a=i==0?"active":"";
        var html=`<table style="width:100%;height:auto;">
            <caption>标题`+i+`</caption>
            <tr>
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            </tr>
            <tr>
            <td>a</td>
            <td>b</td>
            <td>c</td>
            <td>d</td>
            <td>e</td>
            </tr>
            </table>`
        $("<li class=a>"+html+"</li>").appendTo($(".rightContent"));

        $(".aa")[i].onclick=function () {
            $(".rightContent div").remove();
            $(".rightContent li").each(function (j) {
                $(".rightContent li").removeClass("active");
            })
            $(".rightContent li").each(function (j) {
                if(i==j){
                    $(".rightContent li").eq(j).addClass("active");
                }
            })
        }
    })

})
