﻿$(function(){
	var getYuangongId=localStorage.getItem("edit_id");
	$("input[name='id']").val(getYuangongId);

function sele(r){
	$.ajax({
		type:"get",
		dataType:"json",
		url:uRl+"/info/infotz/add?lx=1",
		 success:function(data){
            console.log(data);
            var sblx=data.result.type;
            var str1='<option value="0">请选择</option>';
            $.each(sblx, function(i,v) {
            	str1 +='<option value='+v.id+'>'+v.title+'</option>';
            });
            
            $("[name=type]").html(str1);
        }
	});
}


//	------------------------
	if(getYuangongId==''||getYuangongId==null){  //如果存在修改id 则执行修改函数追加书数据
		sele('1')
		addedit("add");

	}else{
		sele('0');
		zhuijia();
		addedit("edit")
	}

//修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
		type:'get',
   		dataType:"json",
   		asyn:false,
   		beforeSend:function(){
   			 console.log("开始发送");
   		},
   		data:{id:getYuangongId},
		url:uRl+"/info/infotz/one_info",
		success:function(data){
			if(data.status==1){
				 console.log(data);
				 var tp=data.result.type
				 var str='<option value="0">请选择</option>';
				 $.each(tp, function(i,v) {
				 	if(data.result.info.type==v.id){
				 		str +="<optin value='"+v.id+"' selected>"+v.title+"<option/>"
				 	}else{
				 		str +="<optin value='"+v.id+"'>"+v.title+"<option/>"
				 	}
				 });
				 /*for(var str in data.result.type){
	                if($('#yuangong_submit3 [name=' + str + ']').attr("type")=="radio"){
	                    $('#yuangong_submit3 [name=' + str + ']').eq(data.result.status[str]).attr("checked","checked")
	                }
	                else if($('#yuangong_submit3 [name=' +'"'+ str + 's[]"]').attr("type")=="checkbox"){
	                    var len=data.result.user_info[str].length;
	                    for(var i=0;i<len;i++){
	                        for(var r=0;r<$('#yuangong_submit3 [name=' +'"'+ str + 's[]"]').length;r++){
	                            if($('#yuangong_submit3 [name=' +'"'+ str + 's[]"]')[r].value==data.result.user_info[str][i]){
	                                $('#yuangong_submit3 [name=' +'"'+ str + 's[]"]')[r].setAttribute("checked","checked")
	                            }
	                        }
	                    }
	                }
	                
	                else if($('#yuangong_submit3 [name=' + str + ']').attr("type")=="file"){
	                 	continue;
	                }
	                else{$('#yuangong_submit3 [name=' + str + ']').val(data.result.type[str])}
	           };*/
	          
				$("[name='name']").val(data.result.info);
				$("[name='bianhao']").val(data.result.bianhao);
				$("[name='xinghao']").val(data.result.xinghao);
				$("[name='changjia']").val(data.result.changjia);
				$("[name='c_name']").val(data.result.c_name);
				$("[name='a_addtime']").val(data.result.a_addtime);
				$("[name='z_name']").val(data.result.z_);
				$("[name='name']").val(data.result.info);
				$("[name='s_danwei']").val(data.result.s_danwei);
				
			}
			if(data.status==0) alert("参数错误");
		},
		complete:function(){
			console.log("接收成功");
		}
	})
	}

//	-------------------点击提交-------------------------------

	function addedit(r){
		$("#saveYuanGongInfo").click(function(){
			if($("input[name='gid']").val()==""){
				notify("管理编号不能空!", "inverse");
			}else if($("select[name='type']").val()==""){
				notify("设备类型必须选择!", "inverse");
			}else if($("input[name='name']").val()==""){
				notify("设备名称必须选择!", "inverse");
			}else if($("input[name='bianhao']").val()==""){
				notify("设备编号必须选择!", "inverse");
			}else if($("select[name='xinghao']").val()==""){
				notify("规格型号必须选择!", "inverse");
			}else if($("select[name='changjia']").val()==""){
				notify("生产厂家必须选择!", "inverse");
			}else if($("select[name='j_time']").val()==""){
				notify("进场时间必须选择!", "inverse");
			}else if($("select[name='t_time']").val()==""){
				notify("退场时间必须选择!", "inverse");
			}else{
				$.ajax({
					url: uRl+"/info/infotz/"+r,
			 		type:'post',
			 		dataType:"json",
			 		asyn:false,
				    data:$('#yuangong_submit3').serialize(),
				    success:function(data,textStatus,jqXHR){
				       	console.log(data)
				       	if(localStorage.getItem("edit_id")){
				       		localStorage.removeItem("edit_id")//请求成功后 清空 修改id
				       	}
				       if(data.status==1){
				       	console.log("发送成功");
				      	location.href="#/app/Employees";
				       }
				       if(data.status==0){
				       	console.log("发送失败");
				       }
				    }
			    })
			}
			// localStorage.clear();
	   })
	}
$("[name='zp']").click(function(){
	$("#upmodal_title").text("员工照片信息上传");
	$('#upmodal').modal('show');
})
$('.form_date').datetimepicker({
    language:  'zh-CN',
    pickerPosition: "bottom-left",
    weekStart: 1,
    todayBtn:  1,
	autoclose: 1,
	todayHighlight: 1,
	startView: 2,
	minView: 2,
	forceParse: 0,
	format:'yyyy-mm-dd'
});

	



})//end
