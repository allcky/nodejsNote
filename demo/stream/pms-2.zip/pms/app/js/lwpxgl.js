var scrolly = document.body.clientHeight - 360; // 高度设定
var thisName;
$(document).ready(function() {
	var table = $('#table_peixunjihua').DataTable({
		"searching": false, //本地搜索
		"lengthChange": false, //修改每页显示数量
		"pageLength": 10, //单页显示数据条数
		checkAllId: "employeeCheckAll",
		"paging": true, //是否显示分页
		"processing": true, //显示处理状态	
		"serverSide": true, //启动覆盖页分页
		"autoWidth": true, //是否自适应宽度 
		"scrollCollapse": true,
		"scrollY": scrolly,
		"ajax": {
			"url": uRl + '/renyuan/peixun/index',
			"error": function(jqXHR, textStatus, errorMsg) {
				notify("数据加载失败!", "inverse");
			}
		},
		"columns": [{
				"sClass": "text-center",
				"data": "id",
				"render": function(data, type, full, meta) {
					return '<input type="checkbox" name="jihua"  value="' + data + '" />';
				},
				"bSortable": false
			},
			{
				data: "mc"
			},
			{
				data: "fzr"
			},
			{
				data: "skr"
			},
			{
				data: "skrzw"
			},
			{
				data: "zf"
			},
			{
				data: "statetime"
			},
			{
				data: "addtime"
			},
			{
				data: "hgx"
			}
		],
		"language": {
			"sProcessing": "数据加载中...",
			"sLengthMenu": "显示 _MENU_ 条结果",
			"sInfo": "显示第 _START_ 至 _END_ 项  作业人员培训信息，共 _TOTAL_ 条",
			"sInfoEmpty": "显示第 0 至 0 条员工信息，共 0 条",
			"sLoadingRecords": "载入中...",
			"sInfoThousands": ","
		},
		"createdRow": function ( row, data, index ) {
			$('td', row).eq(0).css('text-align',"left");
			
        },
	});

	//给行绑定选中事件
	$('#table_peixunjihua tbody').on('click', 'tr', function() {
		if($(this).hasClass('selected')) {
			$('tr.selected input')[0].checked = false;
			$(this).removeClass('selected');
		} else {
			if($("[name='jihua']:checkbox:checked").length > 0) {
				$("[name='jihua']:checkbox:checked")[0].checked = false;
			};
			table.$('tr.selected').removeClass('selected');
			$(this).addClass('selected');
			$('tr.selected input')[0].checked = true;
		}
	});
	//				//全选删除
	$("[name=checkAll]").click(function() {
		var check = $(this).prop("checked");
		$("[name='jihua']").prop("checked", check);
	});
	//单选删除
	$("#del").click(function() {
		// 检测选中状态
		if($("[name='jihua']:checkbox:checked").length == 0) {
			notify('请先选中要删除的数据', 'danger');
			return false;
		} else if($("[name='jihua']:checkbox:checked").length == 1) {
			// 单条删除
			// 行
			var tr = $('#table_peixunjihua .selected')[0];
			// 行id
			var id = $('#table_peixunjihua .selected input')[0].value;
			//逻辑删除
			Common.confirm({message:"确认删除员工培训计划吗？",operate:function(reselt){if(reselt){
				$.ajax({
					type: "post",
					url: uRl + "/renyuan/peixun/delete",
					async: true,
					data: {
						id: id
					},
					success: function(data) {
						console.log(data);
						if(data.status == 1) {
							//物理删除
							$(tr).remove();
							notify("删除成功!", "success");
						} else if(data.status == 0) {
							notify("删除失败!", "danger");
						}
						table.ajax.reload();
					}
				});
			}}});
		} else if($("[name='jihua']:checkbox:checked").length > 1) {
			//全部删除开始
			//定义数组ids
			var ids = [];
			for(var i = 0; i < $("[name='jihua']:checkbox:checked").length; i++) {
				var id = $('[name=jihua]')[i].value;
				ids.push(id);
			};
			//全部删除ajax    逻辑删除
			$.ajax({
				type: "post",
				url: uRl + "/renyuan/peixun/delete",
				async: true,
				data: {
					id: ids
				},
				success: function(data) {
					if(data.status == 1) {
						//物理删除
						$(tr).remove();
						notify("删除成功!", "inverse");
					} else if(data.status == 0) {
						notify("删除失败!", "inverse");
					}
					//刷新数据源
					table.ajax.reload();
				}
			});
		}
	});
	//刷新
	$('#reload').click(function() {
		table.ajax.reload();
	});
	//添加
	$('#add').click(function() {
		//					console.log('添加数据');
		thisName = this.id;
		if(thisName == "add") {
			createLoading("lwpxgl_edit", "#showModal1", "#showModal2", "jz");
		}
	});
	//修改
	$('#edit').click(function() {
		thisName = this.id;
		// 修改
		if($("[name='jihua']:checkbox:checked").length != 1) {
			notify('请先选中要修改的数据', 'danger');
			return false;
		}
		if(thisName == "edit") {
			createLoading("lwpxgl_edit", "#showModal1", "#showModal2", "jz");
		}
	});
	$("[name=save_button1]").click(function() {
		var mc = $("[name=mc]").val();
		var fzr = $("[name='fzr']").val();
		var skr = $("[name='skr']").val();
		var zf = $("[name='zf']").val();
		var hgx = $("[name='hgx']").val();
		var bz = $("[name='bz']").val();
		var statetime=$("[name='statetime']").val();
		var addtime=$("[name='addtime']").val();
		if (mc==""|| mc==null) {
			notify("培训名称不能为空!","danger");
		}else if (fzr==""||fzr==null) {
			notify("负责人不能为空!","danger");
		}else if (skr==""||skr==null) {
			notify("授课人不能为空!","danger");
		}else if (zf==""||zf==null) {
			notify("总分不能为空!","danger");
		}else if (hgx==""||hgx==null) {
			notify("合格线不能为空!","danger");
		}else if (statetime==""||statetime==null) {
			notify("开始时间不能为空!","danger");
		}else if (addtime==""||addtime==null) {
			notify("添加时间不能为空!","danger");
		}
		if($("[name='jihua']:checkbox:checked").length <= 0) {
			// 新增
			$.ajax({
				type: "post",
				url: uRl + "/renyuan/peixun/add",
				async: true,
				data: {
					mc: mc,
					fzr: fzr,
					skr: skr,
					zf: zf,
					statetime: statetime,
					addtime: addtime,
					hgx: hgx,
					bz: bz
				},
				success: function(data) {
//					console.log(data);
					$('#showModal1').modal('hide');
					table.ajax.reload();
				}
			});
		} else {
			var id = $("[name='jihua']:checkbox:checked")[0].value;
			$.ajax({
				type: "post",
				url: uRl + "/renyuan/peixun/edit",
				async: true,
				data: {
					id: id,
					mc: mc,
					fzr: fzr,
					skr: skr,
					skrzw: skrzw,
					zf: zf,
					statetime: statetime,
					addtime: addtime,
					hgx: hgx,
					bz: bz
				},
				success: function(data) {
					console.log(data);
					$('#showModal').modal('hide');
					table.ajax.reload();
				}
			});
		}

	});
	//全文检索
	//检索功能
	var this_name;
	$("#setting>li").click(function(){
		var html=$(this).find("a").text();
		var cla=$(this).find("a>i").attr("class");
		$("#content_qwjs").html(html);
		$("#content_qwjs11").attr("class",cla);
		this_name=$(this).find("a")[0].name;
	});
	//获取搜索框里面的内容
	$('#search').click(function(){
		if (this_name==undefined||this_name=="") {
			notify("请选择类型!","danger");
		}else{
			if ($("#search_content").val()==""||$("#search_content").val()==null) {
				notify("请输入内容","danger");
				return false;
			}else{
				var getValue=$("#search_content").val();
				tableUrl=uRl + "/renyuan/peixun/index?lx=1&"+this_name+"="+getValue;
				table.ajax.url(tableUrl).load();
				this_name="";
			};
		}
	});
	
	
	
	
	
});