$('.form_date').datetimepicker({
	language: 'zh-CN',
	pickerPosition: "bottom-left",
	weekStart: 1,
	todayBtn: 1,
	autoclose: 1,
	todayHighlight: 1,
	startView: 2,
	minView: 2,
	forceParse: 0,
	format: 'yyyy-mm-dd'
});

$(function() {
	$("[name=ssid]").change(function() {
		ssid($("[name=ssid] option:selected").attr('data-jb'));
	})
	var getYuangongId = id_name;
	$("input[name='ssid']").val(ssid);
	if(getYuangongId == "" || getYuangongId == undefined) {
		ajaxurl = "/xiangmu/xmjh/add";
		sele()
	} else {
		ajaxurl = "/xiangmu/xmjh/one_info";
		one_info()
	}
	//修改追加数据 ;
function one_info() {
	$.ajax({
		type: 'get',
		dataType: "json",
		asyn: false,
		data: { id: getYuangongId, lx: 1 },
		url: uRl + ajaxurl,
		success: function(data) {
//			console.log(data)
			if(data.status == 1) {
				var bumen = data.result.bumen;
				resstr = data.result.info;
				creatData(data.result.quyu, resstr.t_yg_qy_id);
				var bw = data.result.bw;
				var stst = "";
				$.each(bw, function(i, e) {
					if(e.id==data.result.info.t_xm_sgbw_id){
						stst += "<option selected value='" + e.id + "'>" + e.mc + "</option>";
					}else{
						stst += "<option value='" + e.id + "'>" + e.mc + "</option>";
					}
				
				if(e.children != '') {
					$.each(e.children, function(i, ee) {
						if(ee.id==data.result.info.t_xm_sgbw_id){
						  stst += "<option selected value='" + ee.id + "'>&nbsp;&nbsp;&nbsp;" + ee.mc + "</option>";
					    }else{
						  stst += "<option value='" + ee.id + "'>&nbsp;&nbsp;&nbsp;" + ee.mc + "</option>";
					    }
						
					});
				}
			});
				$("[name=t_xm_sgbw_id]").html(stst);
				stst = "";
				
				//
			    html1 = "";
			    str = "";
			    xzsj(data.result.jh,data.result.info.ssid);
				$("[name='mc']").val(resstr.mc);
				$("[name='bz']").val(resstr.bz);
				aa(bumen, id_name);
				$("[name=ssid]").html(html1);
				str = "";
			}else if(data.status == 0){
				notify("参数错误","danger");
			}
		}
	})
}
}) //end
var html1 = "<option value='0'>年度计划</option>";
var str = "";

function aa(datal, info) {
	for(var i = 0; i < datal.length; i++) {
		var id = datal[i].id;
		var mc = datal[i].name;
		var jibie = datal[i].jb;
		if(info != 0) {
			if(info.ssid == id) {
				html1 += '<option value="' + id + '" selected data-jb="' + jibie + '">' + str + mc + '</option>';
			} else {
				if(jibie == 4) {
					html1 += '<option value="" disabled>' + str + mc + '</option>';
				} else {
					html1 += '<option value="' + id + '" data-jb="' + jibie + '">' + str + mc + '</option>';
				}
			}
		} else {
			if(jibie == 4) {
				html1 += '<option value="" disabled>' + str + mc + '</option>';
			} else {
				html1 += '<option value="' + id + '" data-jb="' + jibie + '">' + str + mc + '</option>';
			}

		}
		if(datal[i].children != null) {
			aa(datal[i].children, info);
		}
	}

}

function creatData(data, dataid) {
	var html = "<option value='0'>请选择</option>";
	if(dataid) {
		$.each(data, function(i, e) {
			if(dataid == e.id) {
				html += "<option  value=" + e.id + " selected>" + e.mc + "</option>";
			} else {
				html += "<option  value=" + e.id + ">" + e.mc + "</option>";
			}
		});
	} else {
		$.each(data, function(i, e) {
			html += "<option  value=" + e.id + ">" + e.mc + "</option>";
		});
	}

	$("[name=t_yg_qy_id]").html(html);
}

function creatData1(data, dataid) {
	var html = "<option value='0'>请选择</option>";
	if(dataid) {
		$.each(data, function(i, e) {
			if(dataid == e.id) {
				html += "<option  value=" + e.id + " selected>" + e.xm + "</option>";
			} else {
				html += "<option  value=" + e.id + ">" + e.xm + "</option>";
			}
		});
	} else {
		$.each(data, function(i, e) {
			html += "<option  value=" + e.id + ">" + e.xm + "</option>";
		});
	}

	$("[name=t_yg_ry_id]").html(html);
}
//寻找上级函数
function xzsj(datal,info){
	var mc;
	for(var i=0;i<datal.length;i++){
	 	if(info!=0){
	 		if(info==datal[i].id){
	 		  	mc=datal[i].name;
	 		   	if(mc==""||mc==null){
                 	mc="一级部门";
                 	resstr.ssid=0;
                }
                $("#cbad").val(mc);
                $("[name=t_yg_bm_id]").val(datal[i].id);
	 		  return mc;
	 		}else{
	 			if(datal[i].children!=null){
			        xzsj(datal[i].children,info);
		         }
	 		}
	 	}
		
	}
	
}






//
function sele() {
	$.ajax({
		type: "get",
		dataType: "json",
		url: uRl + ajaxurl,
		success: function(data) {
			console.log(data);
			var jh = data.result.jh;
			var qy = data.result.quyu;
		
			var bw = data.result.bw;
			var userlist = data.result.userlist;
			creatData1(userlist, 0);
			var stst = "";
			$.each(bw, function(i, e) {
				stst += "<option value='" + e.id + "'>" + e.mc + "</option>";
				if(e.children != '') {
					$.each(e.children, function(i, ee) {
						stst += "<option value='" + ee.id + "'>&nbsp;&nbsp;&nbsp;" + ee.mc + "</option>";
					});
				}
			});
			$("[name=t_xm_sgbw_id]").html(stst);
			stst = "";
			aa(jh, 0);
			$("[name=ssid]").html(html1);
			creatData(qy, 0);
			html1 = "";
			str = "";
		}
	});
}


function ssid(aa) {
	if(aa == 3) {
		var qy = $("[name=t_yg_qy_id]").val();
		if(qy == 0) {
			notify("请选择施工区域","inverse");
			return false;
		} else {
			$.ajax({
				type: 'get',
				dataType: "json",
				asyn: false,
				beforeSend: function() {
				
				},
				data: { id: qy },
				url: uRl + "/xiangmu/xmjh/getsgbw",
				success: function(data) {
					if(data.status == 1) {
					
						var bw = data.result.bw;
						var html = "";
						$.each(bw, function(i, e) {
							html += "<option  value=" + e.id + ">" + e.mc + "</option>";
						});
						$("[name=t_xm_sgbw_id]").html(html);
					}else if(data.status == 0){
						notify("参数错误","danger");	
					} 
				}
			})
		}

	}
}