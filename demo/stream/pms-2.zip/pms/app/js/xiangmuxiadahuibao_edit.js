$(function(){
	var getYuangongId=localStorage.getItem("edit_id");
	$("input[name='id']").val(getYuangongId);

function sele(r){
	$.ajax({
		type:"get",
		dataType:"json",
		url:uRl+"/renyuan/yuangong/add?lx=1",
		 success:function(data){
//          console.log(data);
            var bumen=data.result.bumen;
            var gw=data.result.gwmb;
            var zw=data.result.zwmb;
            var str1='<option value="0">请选择</option>';
            var str2='<option value="0">请选择</option>';
            var str3='<option value="0">请选择</option>';
            $.each(bumen, function(i,v) {
            	str1 +='<option value='+v.id+'>'+v.mc+'</option>'
            });
            
            $.each(gw, function(i,v) {
            	str2 +="<option value='"+v.id+"'>"+v.mc+"</option>"
            });
            $.each(zw, function(i,v) {
            	str3+="<option value='"+v.id+"'>"+v.mc+"</option>"
            });
            $("[name='gw_t_sys_mb_id']").html(str2);
            $("[name='zw_t_sys_mb_id']").html(str3);
            $("[name=t_yg_bm_id]").html(str1);
            if(r==1){
            	$("[name='gw_t_sys_mb_id']").chosen();
 			$("[name='zw_t_sys_mb_id']").chosen();
 			$("[name='t_yg_bm_id']").chosen();
            }
           
        }
	});
}


//	------------------------
	if(getYuangongId==''||getYuangongId==null){  //如果存在修改id 则执行修改函数追加书数据
		sele('1')
		addedit("add");
		$("#mb_xx").text("员工信息录入");
	}else{
		sele('0');
		zhuijia();
		addedit("edit");
		$("#mb_xx").text("员工信息修改");
	}


//修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
		type:'get',
   		dataType:"json",
   		asyn:false,
   		beforeSend:function(){
   			 console.log("开始发送");
   		},
   		data:{id:getYuangongId},
		url:uRl+"/renyuan/yuangong/one_info",
		success:function(data){
			if(data.status==1){
				console.log(data);
				resstr=data.result.user_info;
				//改变图像地址
				if(resstr.tx=="" || resstr.tx==null){
					txstr="app/img/pms_logo.png";
				}else{
					txstr="servies/two/public"+resstr.tx;
				}
				$("[name='zp']").attr("src",txstr);
				$("[name='xm']").val(resstr.xm);
				//单选框赋值
				if(data.result.user_info.xb=="男"){
					$('#yuangong_submit3 [name=xb]').eq(0).attr("checked","checked")
				}else if(data.result.user_info.xb=="女"){
					$('#yuangong_submit3 [name=xb]').eq(1).attr("checked","checked")
				}
				$("[name='csrq']").val(resstr.csrq);
				$("[name='cjgzrq']").val(resstr.cjgzrq);
				$("[name='zyjszc']").val(resstr.zyjszc);
				$("[name='prsj']").val(resstr.prsj);
				$("[name='gw_t_sys_mb_id']").val(resstr.gw_t_sys_mb_id);
				$("[name='zw_t_sys_mb_id']").val(resstr.zw_t_sys_mb_id);
				$("[name='t_yg_bm_id']").val(resstr.t_yg_bm_id);
				//单选框赋值
				if(data.result.user_info.sfzg=="1"){
					$('#yuangong_submit3 [name=sfzg]').eq(0).attr("checked","checked")
				}else if(data.result.user_info.xb=="0"){
					$('#yuangong_submit3 [name=sfzg]').eq(1).attr("checked","checked")
				}
				$("[name='lxfs']").val(resstr.lxfs);
				$("[name='sczy']").val(resstr.sczy);
				$("[name='xjzd']").val(resstr.xjzd);
				$("[name='xgtd']").val(resstr.xgtd);
				$("[name='bz']").val(resstr.bz);
				$("[name='lx']").val(resstr.lx);
				$("[name='tx']").val(resstr.tx);
				$("[name='id']").val(resstr.id);
//          }
			
			}
			if(data.status==0) alert("参数错误");
			

			$("[name='gw_t_sys_mb_id']").chosen();
 			$("[name='zw_t_sys_mb_id']").chosen();
 			$("[name='t_yg_bm_id']").chosen();

 			
 		
			
		},
		complete:function(){
			console.log("接收成功");
		}
	})
	}

//	-------------------点击提交-------------------------------

	function addedit(r){
		
		$("#saveYuanGongInfo").click(function(){
		var xb=$('input:radio[name="xb"]:checked').val();
		var sfzg=$('input:radio[name="sfzg"]:checked').val();
		if($("input[name='xm']").val()==""){
			notify("姓名不能空!", "inverse");
		}else if(xb==null){
			notify("性别必须选择!", "inverse");
		}else if($("input[name='csrq']").val()==""){
			notify("出生日期必须选择!", "inverse");
		}else if($("input[name='cjgzsj']").val()==""){
			notify("参加工作时间必须选择!", "inverse");
		}else if($("select[name='gw_t_sys_mb_id']").val()=="0"){
			notify("岗位必须选择!", "inverse");
		}else if($("select[name='zw_t_sys_mb_id']").val()=="0"){
			notify("职务必须选择!", "inverse");
		}else if($("select[name='t_yg_bm_id']").val()=="0"){
			notify("部门必须选择!", "inverse");
		}else if(sfzg==null){
			notify("是否在岗必须选择!", "inverse");
		}else{
			$.ajax({
				url: uRl+"/renyuan/yuangong/"+r,
		 		type:'post',
		 		dataType:"json",
		 		asyn:false,
			    data:$('#yuangong_submit3').serialize(),
			    success:function(data,textStatus,jqXHR){
			       	console.log(data)
			       	if(localStorage.getItem("edit_id")){
			       		localStorage.removeItem("edit_id")//请求成功后 清空 修改id
			       	}
			       if(data.status==1){
			       	console.log("发送成功");
			      	location.href="#/app/Employees";
			       }
			       if(data.status==0){
			       	console.log("发送失败");
			       }
			    }
		    })
		}
			// localStorage.clear();
	   })
	}
	$("[name='zp']").click(function(){
		$("#upmodal_title").text("员工照片信息上传");
		$('#upmodal').modal('show');
	})
	$('.form_date').datetimepicker({
	    language:  'zh-CN',
	    pickerPosition: "bottom-left",
	    weekStart: 1,
	    todayBtn:  1,
		autoclose: 1,
		todayHighlight: 1,
		startView: 2,
		minView: 2,
		forceParse: 0,
		format:'yyyy-mm-dd'
	});
})//end
