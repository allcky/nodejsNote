function xs_menu(curl,xsid,mbid,shuid,hiddid,xzlx){
	var setting = {
		view: {
			dblClickExpand: false
		},
		data: {
			simpleData: {
				enable: true
			}
		},
		callback: {
			beforeClick: beforeClick,
			onClick: onClick
		}
	};
	$.ajax({  
	    url : curl,  
	    type : 'get',  
	    dataType : 'json',  
	    timeout : 1000,  
	    error : function(){
	        notify("网络延时，请重试.","inverse");
	    },  
	    success : function(res){  
	        treeNodes = res.result.bumen; 
	       $.fn.zTree.init($("#"+shuid), setting, treeNodes); 
	    }  
    });
	
	var cityObj = $("#"+xsid);
	var cityOffset = $("#"+xsid).offset();
	$("#"+mbid).slideDown("fast");

	$("body").bind("mousedown", onBodyDown);
	
	
	function beforeClick(treeId, treeNode) {
		if(xzlx=="1"){
			var check = (treeNode.ssid);
			if (!check);
			return check;
		}
	}
	
	function onClick(e, treeId, treeNode) {
		var zTree = $.fn.zTree.getZTreeObj(shuid),
		nodes = zTree.getSelectedNodes(),
		v = "",
		w="";
		nodes.sort(function compare(a,b){return a.id-b.id;});
		for (var i=0, l=nodes.length; i<l; i++) {
			v += nodes[i].name + ",";
			w += nodes[i].id + ",";
		}
		if (v.length > 0 ) v = v.substring(0, v.length-1);
		if (w.length > 0 ) w = w.substring(0, w.length-1);
		var cityObj = $("#"+xsid);
		var hiddObj = $("#"+hiddid);
		cityObj.val(v);
		hiddObj.val(w);
	}
	function hideMenu() {
		$("#"+mbid).fadeOut("fast");
		$("body").unbind("mousedown", onBodyDown);
	}
	function onBodyDown(event) {
		if (!(event.target.id == "menuBtn" || event.target.id == mbid || $(event.target).parents("#"+mbid).length>0)) {
			hideMenu();
		}
	}
}

//测试
function GetRandomNum(Min,Max)
{   
var Range = Max - Min;   
var Rand = Math.random();   
return(Min + Math.round(Rand * Range));   
}  




//loading函数
//m2指的是加载数据框
//m1指的是显示页面框
//u指的是显示页面路径
//lx显示或影藏 jz加载页面
function createLoading(u,m1,m2,lx){
	if (lx=="jz"){
		$("body").mLoading();
		$(m1).find(".modal-body").load('app/views/'+u+'.html?time='+new Date().getSeconds());
		$(m1).modal('show');
	}else if(lx==""){
		$(m1).modal('hide');
	}

};
var Common = {
    confirm:function(params){
        var model = $("#common_confirm_model");
//        model.find(".title").html(params.title);
        model.find(".message").html(params.message);
        $("#common_confirm_btn").click()
        //每次都将监听先关闭，防止多次监听发生，确保只有一次监听
        model.find(".cancel").off("click")
        model.find(".ok").off("click")

        model.find(".ok").on("click",function(){
            params.operate(true)
        })

        model.find(".cancel").on("click",function(){
            params.operate(false)
        })
    }
}

function xs_menu1(curl,xsid,mbid,shuid,hiddid,xzlx){
	var setting = {
		view: {
			dblClickExpand: false
		},
		data: {
			simpleData: {
				enable: true
			}
		},
		callback: {
			beforeClick: beforeClick,
			onClick: onClick
		}
	};
	$.ajax({  
	    url : curl,  
	    type : 'get',  
	    dataType : 'json',  
	    timeout : 1000,  
	    error : function(){
	        notify("网络延时，请重试.","inverse");
	    },  
	    success : function(res){  
	        treeNodes = res.result.yllx; 
	       $.fn.zTree.init($("#"+shuid), setting, treeNodes); 
	    }  
    });
	
	var cityObj = $("#"+xsid);
	var cityOffset = $("#"+xsid).offset();
	$("#"+mbid).slideDown("fast");

	$("body").bind("mousedown", onBodyDown);
	
	
	function beforeClick(treeId, treeNode) {
		if(xzlx=="1"){
			var check = (treeNode.ssid);
			if (!check);
			return check;
		}
	}
	
	function onClick(e, treeId, treeNode) {
		var zTree = $.fn.zTree.getZTreeObj(shuid),
		nodes = zTree.getSelectedNodes(),
		v = "",
		w="";
		nodes.sort(function compare(a,b){return a.id-b.id;});
		for (var i=0, l=nodes.length; i<l; i++) {
			v += nodes[i].name + ",";
			w += nodes[i].id + ",";
		}
		if (v.length > 0 ) v = v.substring(0, v.length-1);
		if (w.length > 0 ) w = w.substring(0, w.length-1);
		var cityObj = $("#"+xsid);
		var hiddObj = $("#"+hiddid);
		cityObj.val(v);
		hiddObj.val(w);
	}
	function hideMenu() {
		$("#"+mbid).fadeOut("fast");
		$("body").unbind("mousedown", onBodyDown);
	}
	function onBodyDown(event) {
		if (!(event.target.id == "menuBtn" || event.target.id == mbid || $(event.target).parents("#"+mbid).length>0)) {
			hideMenu();
		}
	}
}
function xs_menu2(curl,xsid,mbid,shuid,hiddid,xzlx){
	var setting = {
		view: {
			dblClickExpand: false
		},
		data: {
			simpleData: {
				enable: true
			}
		},
		callback: {
			beforeClick: beforeClick,
			onClick: onClick
		}
	};
	$.ajax({  
	    url : curl,  
	    type : 'get',  
	    dataType : 'json',  
	    timeout : 1000,  
	    error : function(){
	        notify("网络延时，请重试.","inverse");
	    },  
	    success : function(res){  
	        treeNodes = res.result.jh; 
	       $.fn.zTree.init($("#"+shuid), setting, treeNodes); 
	    }  
    });
	
	var cityObj = $("#"+xsid);
	var cityOffset = $("#"+xsid).offset();
	$("#"+mbid).slideDown("fast");

	$("body").bind("mousedown", onBodyDown);
	
	
	function beforeClick(treeId, treeNode) {
		if(xzlx=="1"){
			var check = (treeNode.ssid);
			if (!check);
			return check;
		}
	}
	
	function onClick(e, treeId, treeNode) {
		var zTree = $.fn.zTree.getZTreeObj(shuid),
		nodes = zTree.getSelectedNodes(),
		v = "",
		w="";
		nodes.sort(function compare(a,b){return a.id-b.id;});
		for (var i=0, l=nodes.length; i<l; i++) {
			v += nodes[i].name + ",";
			w += nodes[i].id + ",";
		}
		if (v.length > 0 ) v = v.substring(0, v.length-1);
		if (w.length > 0 ) w = w.substring(0, w.length-1);
		var cityObj = $("#"+xsid);
		var hiddObj = $("#"+hiddid);
		cityObj.val(v);
		hiddObj.val(w);
	}
	function hideMenu() {
		$("#"+mbid).fadeOut("fast");
		$("body").unbind("mousedown", onBodyDown);
	}
	function onBodyDown(event) {
		if (!(event.target.id == "menuBtn" || event.target.id == mbid || $(event.target).parents("#"+mbid).length>0)) {
			hideMenu();
		}
	}
}