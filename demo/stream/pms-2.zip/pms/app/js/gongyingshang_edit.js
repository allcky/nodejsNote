$(function() {
	var getYuangongId = id_name;
	$("input[name='id']").val(getYuangongId);
	if(getYuangongId == "" || getYuangongId == undefined) {
		$(".modal-title").html("供应商信息录入");
		sele('add');
	} else {
		$(".modal-title").html("供应商信息修改");
		sele('edit');
		zhuijia();
	}
	function sele(r) {
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + "/yuanliao/gys/"+r,
			success: function(data) {
				createLoading("gongyingshang_edit","#showModal1","#showModal2","");
				if(data.status == 1) {
					console.log("发送成功");
				}else if (data.status == 0) {
					console.log("发送失败");
				}
			},
			error:function(data){
				console.log("发送失败");
			}
		});
	}
	////修改追加数据  zhuijia();
	function zhuijia(){
		$.ajax({
			type:'get',
	   		dataType:"json",
	   		asyn:false,
	   		beforeSend:function(){
	   			console.log("开始发送");
	   		},
	   		data:{id:getYuangongId},
			url:uRl+"/yuanliao/gys/one_info",
			success:function(data){
			createLoading("gongyingshang_edit","#showModal1","#showModal2","");
				if(data.status==1){
					$("[name=mc]").val(data.result.info.mc);
					$("[name=lxr]").val(data.result.info.lxr);
					$("[name=lxdh]").val(data.result.info.lxdh);
					$("[name=dzyj]").val(data.result.info.dzyj);
	          };
			},complete:function(){
				console.log("接收成功");
			}
		})
	}
}) //end