$(function() {
	var getYuangongId = localStorage.getItem("edit_id");
	$("input[name='id']").val(getYuangongId);
	//	------------------------
	if(getYuangongId == '' || getYuangongId == null) { //如果存在修改id 则执行修改函数追加书数据
		sele('1')
//		addedit("add");
		$("#myModalLabel").text("添加施工部位信息");
	} else {
		sele('0');
		zhuijia();
//		addedit("edit?id=" + getYuangongId);
		$("#myModalLabel").text("修改施工部位");
	}
	var html1 = "";
	var str = "";
	//下拉菜单遍历
	function aa(datal, info) {
		for(var i = 0; i < datal.length; i++) {
			var id = datal[i].id;
			var mc = datal[i].name;
			var jibie = datal[i].jb;
			switch(jibie) {
				case 1:
					str = "";
					break;
				case 2:
					str = "|——";
					break;
				case 3:
					str = "|————";
					break;
				default:
					str = "|————————";
					break;
			}
			if(info != 0) {
				if(info.id == id) {
					html1 += '<option value="' + id + '" selected>' + str + mc + '</option>';
				} else {
					html1 += '<option value="' + id + '">' + str + mc + '</option>';
				}
			} else {
				html1 += '<option value="' + id + '">' + str + mc + '</option>';
			}
			if(datal[i].children != null) {
				aa(datal[i].children, info);
			}
		}

	}
	$("[name=t_xm_sgbwlx]").change(function() {
		fun_sgbwlx($("[name=t_xm_sgbwlx]").val());
	})
	function fun_sgbwlx(r) {
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + "/xiangmu/sgbw/bwlx?id=" + r,
			success: function(data) {
				var bwlx = data.result.bwlx; //施工部位类型
				var str77 = '<option></option>';
				/*//施工部位类型二级*/
				$.each(bwlx, function(i, v) {
					str77 += "<option value='" + v.id + "' onClick='fun_sgbwlx(" + v.id + ")'>" + v.mc + "</option>"
				})
				$("[name=t_xm_sgbwlx1]").html(str77);
				str77 = '<option></option>';
				$("body").mLoading('hide');
			}
		});
	}
	function sele(r) {
		$.ajax({
			type: "get",
			dataType: "json",
			url: uRl + "/xiangmu/sgbw/add",
			success: function(data) {
				console.log(data);
				var bm = data.result.bumen; //部门列表
				var sgbw = data.result.sgbw; //施工部位
				var sgbwlx = data.result.sgbwlx; //施工部位类型
				var quyu = data.result.quyu; //施工区域
				var userlist = data.result.userlist; //负责人列表
				var str44 = '';
				var str55 = '';
				var str66 = '';
				var str88 = '';
				/*//部门列表*/
				aa(bm, 0);
				$("[name=t_yg_bm_id]").html(html1);
				html1 = "";
				/*//上级部位列表*/
				$.each(sgbw, function(i, v) {
					str88 += "<option value='" + v.id + "'>" + v.mc + "</option>"
				})
				$("[name=ssid]").html(str88);
				str88 = "";
				/*//负责人列表*/
				$.each(userlist, function(i, v) {
					str44 += "<option value='" + v.id + "'>" + v.xm + "</option>"
				})
				$("[name=t_yg_ry_id]").html(str44);
				str44 = "";
				/*//施工部位类型*/
				$.each(sgbwlx, function(i, v) {
					str55 += "<option value='" + v.id + "'>" + v.mc + "</option>"
				})
				$("[name=t_xm_sgbwlx]").html(str55);
				str55 = "";
				/*//施工区域*/
				$.each(quyu, function(i, v) {
					str66 += "<option value='" + v.id + "'>" + v.mc + "</option>"
				})
				$("body").mLoading('hide');
				str66 = "";
			}
		});
	}
}) //end